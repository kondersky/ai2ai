<?php
/**
 * Bulk Operations - Массовые операции с очередью
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;

class BulkOperations
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Массовое добавление URL в очередь
     */
    public static function addUrls(array $urls, string $type = 'URL_UPDATED', string $priority = 'MEDIUM'): array
    {
        $added = 0;
        $errors = [];
        
        foreach ($urls as $url) {
            try {
                // Валидируем URL
                $validator = new UrlValidator();
                
                if (!$validator->validate($url)) {
                    $errors[] = $url . ': ' . implode(', ', $validator->getErrors());
                    continue;
                }
                
                // Очищаем URL
                $url = $validator->clean($url);
                
                // Проверяем дубликат
                if (self::urlExists($url)) {
                    continue;
                }
                
                QueueTable::add([
                    'URL' => $url,
                    'TYPE' => $type,
                    'STATUS' => 'NEW',
                    'PRIORITY' => $priority,
                    'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
                ]);
                
                $added++;
                
            } catch (\Exception $e) {
                $errors[] = $url . ': ' . $e->getMessage();
            }
        }
        
        return [
            'total' => count($urls),
            'added' => $added,
            'errors' => $errors
        ];
    }
    
    /**
     * Массовое удаление из очереди
     */
    public static function removeUrls(array $urls): int
    {
        $connection = Application::getConnection();
        $deleted = 0;
        
        foreach ($urls as $url) {
            $result = $connection->query("
                DELETE FROM b_yc_gindex_queue 
                WHERE URL = '" . $connection->getSqlHelper()->forSql($url) . "'
            ");
            $deleted += $result->getAffectedRowsCount();
        }
        
        return $deleted;
    }
    
    /**
     * Удалить все элементы по статусу
     */
    public static function removeByStatus(string $status): int
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            DELETE FROM b_yc_gindex_queue 
            WHERE STATUS = '" . $connection->getSqlHelper()->forSql($status) . "'
        ");
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Удалить старые записи
     */
    public static function removeOld(int $days = 30): int
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            DELETE FROM b_yc_gindex_queue 
            WHERE DATE_CREATE < DATE_SUB(NOW(), INTERVAL " . intval($days) . " DAY)
            AND STATUS IN ('SENT', 'ERROR')
        ");
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Повторить ошибки
     */
    public static function retryErrors(int $maxAttempts = 3): int
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            UPDATE b_yc_gindex_queue 
            SET STATUS = 'NEW',
                RETRY_AFTER = NULL,
                LAST_ERROR = NULL
            WHERE STATUS = 'ERROR'
            AND ATTEMPTS < " . intval($maxAttempts)
        );
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Обновить приоритеты массово
     */
    public static function updatePriorities(array $ids, string $priority): int
    {
        if (empty($ids)) {
            return 0;
        }
        
        $connection = Application::getConnection();
        $ids = array_map('intval', $ids);
        
        $result = $connection->query("
            UPDATE b_yc_gindex_queue 
            SET PRIORITY = '" . $connection->getSqlHelper()->forSql($priority) . "'
            WHERE ID IN (" . implode(',', $ids) . ")"
        );
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Изменить статус записей
     */
    public static function updateStatus(array $ids, string $status): int
    {
        if (empty($ids)) {
            return 0;
        }
        
        $connection = Application::getConnection();
        $ids = array_map('intval', $ids);
        
        $result = $connection->query("
            UPDATE b_yc_gindex_queue 
            SET STATUS = '" . $connection->getSqlHelper()->forSql($status) . "'
            WHERE ID IN (" . implode(',', $ids) . ")"
        );
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Проверить существование URL в очереди
     */
    public static function urlExists(string $url): bool
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT ID FROM b_yc_gindex_queue 
            WHERE URL = '" . $connection->getSqlHelper()->forSql($url) . "'
            AND STATUS = 'NEW'
            LIMIT 1
        ");
        
        return $result->fetch() !== false;
    }
    
    /**
     * Получить дубликаты
     */
    public static function getDuplicates(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT URL, COUNT(*) as CNT
            FROM b_yc_gindex_queue
            WHERE STATUS = 'NEW'
            GROUP BY URL
            HAVING CNT > 1
        ");
        
        $duplicates = [];
        while ($row = $result->fetch()) {
            $duplicates[] = $row;
        }
        
        return $duplicates;
    }
    
    /**
     * Удалить дубликаты (оставить только первый)
     */
    public static function removeDuplicates(): int
    {
        $connection = Application::getConnection();
        
        // Удаляем все дубликаты кроме первого
        $result = $connection->query("
            DELETE FROM b_yc_gindex_queue 
            WHERE ID NOT IN (
                SELECT * FROM (
                    SELECT MIN(ID)
                    FROM b_yc_gindex_queue
                    WHERE STATUS = 'NEW'
                    GROUP BY URL
                ) as t
            )
            AND STATUS = 'NEW'
        ");
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Экспорт URL из инфоблока в очередь
     */
    public static function exportIblockToQueue(int $iblockId, string $type = 'URL_UPDATED'): array
    {
        \CModule::IncludeModule('iblock');
        
        $added = 0;
        $errors = [];
        
        // Элементы
        $res = \CIBlockElement::GetList(
            [],
            ['IBLOCK_ID' => $iblockId, 'ACTIVE' => 'Y'],
            false,
            false,
            ['ID', 'DETAIL_PAGE_URL', 'IBLOCK_ID']
        );
        
        while ($element = $res->Fetch()) {
            $url = \CIBlock::ReplaceDetailUrl($element['DETAIL_PAGE_URL'], $element, false);
            
            if (!empty($url)) {
                try {
                    if (!self::urlExists($url)) {
                        QueueTable::add([
                            'URL' => $url,
                            'TYPE' => $type,
                            'STATUS' => 'NEW',
                            'PRIORITY' => 'MEDIUM',
                            'IBLOCK_ID' => $iblockId,
                            'ELEMENT_ID' => $element['ID'],
                            'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
                        ]);
                        $added++;
                    }
                } catch (\Exception $e) {
                    $errors[] = $element['ID'] . ': ' . $e->getMessage();
                }
            }
        }
        
        // Разделы
        $res = \CIBlockSection::GetList(
            [],
            ['IBLOCK_ID' => $iblockId, 'ACTIVE' => 'Y'],
            false,
            ['ID', 'SECTION_PAGE_URL', 'IBLOCK_ID']
        );
        
        while ($section = $res->Fetch()) {
            $url = \CIBlock::ReplaceDetailUrl($section['SECTION_PAGE_URL'], $section, false);
            
            if (!empty($url)) {
                try {
                    if (!self::urlExists($url)) {
                        QueueTable::add([
                            'URL' => $url,
                            'TYPE' => $type,
                            'STATUS' => 'NEW',
                            'PRIORITY' => 'LOW',
                            'IBLOCK_ID' => $iblockId,
                            'SECTION_ID' => $section['ID'],
                            'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
                        ]);
                        $added++;
                    }
                } catch (\Exception $e) {
                    $errors[] = 'S' . $section['ID'] . ': ' . $e->getMessage();
                }
            }
        }
        
        return [
            'added' => $added,
            'errors' => $errors
        ];
    }
    
    /**
     * Импорт URL из CSV файла
     */
    public static function importFromCsv(string $filePath, string $type = 'URL_UPDATED'): array
    {
        if (!file_exists($filePath)) {
            return ['error' => 'File not found'];
        }
        
        $urls = [];
        
        if (($handle = fopen($filePath, 'r')) !== false) {
            while (($row = fgetcsv($handle, 0, ';')) !== false) {
                $url = trim($row[0] ?? '');
                if (!empty($url)) {
                    $urls[] = $url;
                }
            }
            fclose($handle);
        }
        
        return self::addUrls($urls, $type);
    }
    
    /**
     * Получить статистику по статусам
     */
    public static function getStatusStats(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT STATUS, COUNT(*) as CNT
            FROM b_yc_gindex_queue
            GROUP BY STATUS
        ");
        
        $stats = [
            'NEW' => 0,
            'SENT' => 0,
            'ERROR' => 0
        ];
        
        while ($row = $result->fetch()) {
            $stats[$row['STATUS']] = (int)$row['CNT'];
        }
        
        return $stats;
    }
}
