<?php
/**
 * Analytics - Расширенная аналитика и статистика
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;

class Analytics
{
    private static $tableQueue = 'b_yc_gindex_queue';
    private static $tableLog = 'b_yc_gindex_log';
    private static $tableQuota = 'b_yc_gindex_quota';
    
    /**
     * Получить статистику за сегодня
     */
    public static function getTodayStats(): array
    {
        $connection = Application::getConnection();
        
        // Sent today
        $sent = $connection->query("
            SELECT COUNT(*) as CNT 
            FROM " . self::$tableQueue . " 
            WHERE STATUS = 'SENT' 
            AND DATE(DATE_SENT) = CURDATE()
        ")->fetch();
        
        // Errors today
        $errors = $connection->query("
            SELECT COUNT(*) as CNT 
            FROM " . self::$tableQueue . " 
            WHERE STATUS = 'ERROR' 
            AND DATE(DATE_SENT) = CURDATE()
        ")->fetch();
        
        // In queue
        $inQueue = $connection->query("
            SELECT COUNT(*) as CNT 
            FROM " . self::$tableQueue . " 
            WHERE STATUS = 'NEW'
        ")->fetch();
        
        // Get quota
        $quota = QuotaTable::getStatus();
        
        return [
            'sent_today' => (int)($sent['CNT'] ?? 0),
            'errors_today' => (int)($errors['CNT'] ?? 0),
            'in_queue' => (int)($inQueue['CNT'] ?? 0),
            'quota_used' => $quota['sent'],
            'quota_limit' => $quota['limit'],
            'quota_percent' => $quota['limit'] > 0 ? round($quota['sent'] / $quota['limit'] * 100, 1) : 0
        ];
    }
    
    /**
     * Получить статистику за неделю
     */
    public static function getWeekStats(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT 
                DATE(DATE_SENT) as DAY,
                COUNT(*) as TOTAL,
                SUM(CASE WHEN STATUS = 'SENT' THEN 1 ELSE 0 END) as SENT,
                SUM(CASE WHEN STATUS = 'ERROR' THEN 1 ELSE 0 END) as ERRORS
            FROM " . self::$tableQueue . "
            WHERE DATE_SENT >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY DATE(DATE_SENT)
            ORDER BY DAY DESC
        ");
        
        $data = [];
        while ($row = $result->fetch()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * Получить статистику по инфоблокам
     */
    public static function getIblockStats(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT 
                IBLOCK_ID,
                COUNT(*) as TOTAL,
                SUM(CASE WHEN STATUS = 'SENT' THEN 1 ELSE 0 END) as SENT,
                SUM(CASE WHEN STATUS = 'ERROR' THEN 1 ELSE 0 END) as ERRORS,
                SUM(CASE WHEN STATUS = 'NEW' THEN 1 ELSE 0 END) as PENDING
            FROM " . self::$tableQueue . "
            WHERE IBLOCK_ID IS NOT NULL
            GROUP BY IBLOCK_ID
            ORDER BY TOTAL DESC
            LIMIT 10
        ");
        
        $data = [];
        while ($row = $result->fetch()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * Получить топ URL по количеству попыток
     */
    public static function getTopFailedUrls(int $limit = 10): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT 
                ID, URL, TYPE, STATUS, ATTEMPTS, LAST_ERROR, DATE_CREATE
            FROM " . self::$tableQueue . "
            WHERE STATUS = 'ERROR'
            ORDER BY ATTEMPTS DESC, DATE_CREATE DESC
            LIMIT " . $limit
        );
        
        $data = [];
        while ($row = $result->fetch()) {
            $data[] = $row;
        }
        
        return $data;
    }
    
    /**
     * Получить среднее время обработки
     */
    public static function getAvgProcessingTime(): float
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT AVG(TIMESTAMPDIFF(SECOND, DATE_CREATE, DATE_SENT)) as AVG_TIME
            FROM " . self::$tableQueue . "
            WHERE STATUS = 'SENT' 
            AND DATE_SENT IS NOT NULL
            AND DATE_CREATE IS NOT NULL
            AND DATE_SENT > DATE_CREATE
        ")->fetch();
        
        return (float)($result['AVG_TIME'] ?? 0);
    }
    
    /**
     * Получить процент успешных запросов
     */
    public static function getSuccessRate(): float
    {
        $connection = Application::getConnection();
        
        $total = $connection->query("
            SELECT COUNT(*) as CNT FROM " . self::$tableQueue . " WHERE STATUS IN ('SENT', 'ERROR')
        ")->fetch();
        
        $sent = $connection->query("
            SELECT COUNT(*) as CNT FROM " . self::$tableQueue . " WHERE STATUS = 'SENT'
        ")->fetch();
        
        $totalCount = (int)($total['CNT'] ?? 0);
        $sentCount = (int)($sent['CNT'] ?? 0);
        
        if ($totalCount === 0) {
            return 100.0;
        }
        
        return round($sentCount / $totalCount * 100, 1);
    }
    
    /**
     * Получить типы контента
     */
    public static function getContentTypes(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT 
                TYPE,
                COUNT(*) as CNT
            FROM " . self::$tableQueue . "
            GROUP BY TYPE
        ");
        
        $data = [];
        while ($row = $result->fetch()) {
            $data[$row['TYPE']] = (int)$row['CNT'];
        }
        
        return $data;
    }
    
    /**
     * Получить последние события
     */
    public static function getRecentEvents(int $limit = 20): array
    {
        return LogTable::getList($limit);
    }
    
    /**
     * Получить сводный отчёт
     */
    public static function getSummaryReport(): array
    {
        return [
            'today' => self::getTodayStats(),
            'week' => self::getWeekStats(),
            'iblocks' => self::getIblockStats(),
            'top_failed' => self::getTopFailedUrls(5),
            'success_rate' => self::getSuccessRate(),
            'avg_time' => self::getAvgProcessingTime(),
            'content_types' => self::getContentTypes()
        ];
    }
    
    /**
     * Экспорт статистики в CSV
     */
    public static function exportToCsv(string $type = 'queue'): string
    {
        $data = [];
        $headers = [];
        
        switch ($type) {
            case 'queue':
                $headers = ['ID', 'URL', 'TYPE', 'STATUS', 'IBLOCK_ID', 'ELEMENT_ID', 'ATTEMPTS', 'DATE_CREATE', 'DATE_SENT', 'LAST_ERROR'];
                $connection = Application::getConnection();
                $result = $connection->query("
                    SELECT * FROM " . self::$tableQueue . "
                    ORDER BY DATE_CREATE DESC
                    LIMIT 1000
                ");
                while ($row = $result->fetch()) {
                    $data[] = $row;
                }
                break;
                
            case 'logs':
                $headers = ['ID', 'EVENT_TYPE', 'MESSAGE', 'QUEUE_ID', 'DATE_CREATE'];
                $data = LogTable::getList(1000);
                break;
                
            case 'quota':
                $headers = ['DATE_DAY', 'SENT_COUNT', 'LIMIT_DAY'];
                $connection = Application::getConnection();
                $result = $connection->query("
                    SELECT * FROM " . self::$tableQuota . "
                    ORDER BY DATE_DAY DESC
                    LIMIT 30
                ");
                while ($row = $result->fetch()) {
                    $data[] = $row;
                }
                break;
        }
        
        $csv = implode(';', $headers) . "\n";
        
        foreach ($data as $row) {
            $csv .= implode(';', array_map(function($item) {
                return str_replace([';', "\n", "\r"], [' ', '', ''], (string)$item);
            }, $row)) . "\n";
        }
        
        return $csv;
    }
}
