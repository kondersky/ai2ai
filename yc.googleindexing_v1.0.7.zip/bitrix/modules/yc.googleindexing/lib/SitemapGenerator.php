<?php
/**
 * XML Sitemap Generator - Генерация XML Sitemap для Indexing API
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Iblock\IblockTable;
use Bitrix\Iblock\ElementTable;
use Bitrix\Iblock\SectionTable;

class SitemapGenerator
{
    private const MODULE_ID = 'yc.googleindexing';
    
    private $siteId;
    private $iblockIds = [];
    private $priority = [];
    private $changefreq = 'weekly';
    
    /**
     * Конструктор
     */
    public function __construct(string $siteId = null)
    {
        $this->siteId = $siteId ?: SITE_ID;
        $this->loadIblocks();
    }
    
    /**
     * Загрузить инфоблоки
     */
    private function loadIblocks(): void
    {
        $enabledIblocks = Option::get(self::MODULE_ID, 'enabled_iblocks', '');
        
        if (!empty($enabledIblocks)) {
            $this->iblockIds = explode(',', $enabledIblocks);
        } else {
            // Получаем все активные инфоблоки
            $res = IblockTable::getList([
                'filter' => ['ACTIVE' => 'Y'],
                'select' => ['ID']
            ]);
            
            while ($row = $res->fetch()) {
                $this->iblockIds[] = $row['ID'];
            }
        }
        
        // Загружаем приоритеты
        foreach ($this->iblockIds as $iblockId) {
            $this->priority[$iblockId] = Option::get(
                self::MODULE_ID, 
                'iblock_priority_' . $iblockId, 
                '0.5'
            );
        }
    }
    
    /**
     * Сгенерировать sitemap для всех инфоблоков
     */
    public function generate(): array
    {
        $urls = [];
        
        foreach ($this->iblockIds as $iblockId) {
            $urls = array_merge($urls, $this->getElementsUrls($iblockId));
            $urls = array_merge($urls, $this->getSectionsUrls($iblockId));
        }
        
        return $urls;
    }
    
    /**
     * Получить URL элементов
     */
    private function getElementsUrls(int $iblockId): array
    {
        $urls = [];
        
        $res = ElementTable::getList([
            'filter' => [
                'IBLOCK_ID' => $iblockId,
                'ACTIVE' => 'Y',
                'ACTIVE_DATE' => 'Y'
            ],
            'select' => ['ID', 'IBLOCK_ID', 'DETAIL_PAGE_URL', 'TIMESTAMP_X', 'SHOW_COUNTER'],
            'limit' => 50000
        ]);
        
        $priority = isset($this->priority[$iblockId]) ? (float)$this->priority[$iblockId] : 0.5;
        
        while ($row = $res->fetch()) {
            $url = $this->makeUrl($row['DETAIL_PAGE_URL']);
            
            if (empty($url)) {
                continue;
            }
            
            $urls[] = [
                'loc' => $url,
                'lastmod' => date('c', strtotime($row['TIMESTAMP_X'])),
                'changefreq' => $this->changefreq,
                'priority' => $priority,
                'type' => 'element',
                'iblock_id' => $iblockId,
                'element_id' => $row['ID']
            ];
        }
        
        return $urls;
    }
    
    /**
     * Получить URL разделов
     */
    private function getSectionsUrls(int $iblockId): array
    {
        $urls = [];
        
        $res = SectionTable::getList([
            'filter' => [
                'IBLOCK_ID' => $iblockId,
                'ACTIVE' => 'Y'
            ],
            'select' => ['ID', 'IBLOCK_ID', 'SECTION_PAGE_URL', 'TIMESTAMP_X'],
            'limit' => 10000
        ]);
        
        while ($row = $res->fetch()) {
            $url = $this->makeUrl($row['SECTION_PAGE_URL']);
            
            if (empty($url)) {
                continue;
            }
            
            $urls[] = [
                'loc' => $url,
                'lastmod' => date('c', strtotime($row['TIMESTAMP_X'])),
                'changefreq' => $this->changefreq,
                'priority' => '0.6',
                'type' => 'section',
                'iblock_id' => $iblockId,
                'section_id' => $row['ID']
            ];
        }
        
        return $urls;
    }
    
    /**
     * Сформировать полный URL
     */
    private function makeUrl(string $url): string
    {
        if (empty($url)) {
            return '';
        }
        
        // Если URL уже абсолютный
        if (strpos($url, 'http') === 0) {
            return $url;
        }
        
        // Получаем протокол и домен
        $context = \Bitrix\Main\Context::getCurrent();
        $scheme = $context->getRequest()->isHttps() ? 'https' : 'http';
        $serverName = $context->getServer()->getServerName();
        
        return $scheme . '://' . $serverName . $url;
    }
    
    /**
     * Сгенерировать XML sitemap
     */
    public function generateXml(): string
    {
        $urls = $this->generate();
        
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        foreach ($urls as $url) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . htmlspecialchars($url['loc']) . '</loc>' . "\n";
            $xml .= '    <lastmod>' . $url['lastmod'] . '</lastmod>' . "\n";
            $xml .= '    <changefreq>' . $url['changefreq'] . '</changefreq>' . "\n";
            $xml .= '    <priority>' . $url['priority'] . '</priority>' . "\n";
            $xml .= '  </url>' . "\n";
        }
        
        $xml .= '</urlset>';
        
        return $xml;
    }
    
    /**
     * Сохранить sitemap в файл
     */
    public function saveToFile(string $path): bool
    {
        $xml = $this->generateXml();
        return file_put_contents($path, $xml) !== false;
    }
    
    /**
     * Отправить все URL в очередь Indexing API
     */
    public function sendAllToQueue(string $type = 'URL_UPDATED'): array
    {
        $urls = $this->generate();
        $added = 0;
        $errors = [];
        
        foreach ($urls as $urlData) {
            try {
                QueueTable::add([
                    'URL' => $urlData['loc'],
                    'TYPE' => $type,
                    'STATUS' => 'NEW',
                    'PRIORITY' => 'MEDIUM',
                    'IBLOCK_ID' => $urlData['iblock_id'],
                    'ELEMENT_ID' => $urlData['element_id'] ?? null,
                    'SECTION_ID' => $urlData['section_id'] ?? null,
                    'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
                ]);
                $added++;
            } catch (\Exception $e) {
                $errors[] = $urlData['loc'] . ': ' . $e->getMessage();
            }
        }
        
        return [
            'total' => count($urls),
            'added' => $added,
            'errors' => $errors
        ];
    }
    
    /**
     * Получить статистику sitemap
     */
    public function getStats(): array
    {
        $urls = $this->generate();
        
        $byType = [
            'element' => 0,
            'section' => 0
        ];
        
        $byIblock = [];
        
        foreach ($urls as $url) {
            $byType[$url['type']]++;
            
            if (!isset($byIblock[$url['iblock_id']])) {
                $byIblock[$url['iblock_id']] = 0;
            }
            $byIblock[$url['iblock_id']]++;
        }
        
        return [
            'total' => count($urls),
            'by_type' => $byType,
            'by_iblock' => $byIblock
        ];
    }
}
