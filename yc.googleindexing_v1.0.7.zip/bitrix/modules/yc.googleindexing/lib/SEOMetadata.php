<?php
/**
 * SEO Metadata - Управление SEO метаданными для Indexing API
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Config\Option;
use Bitrix\Iblock\ElementTable;
use Bitrix\Iblock\SectionTable;

class SEOMetadata
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Получить метаданные для элемента
     */
    public static function getElementMetadata(int $elementId, int $iblockId): array
    {
        $metadata = [
            'title' => '',
            'description' => '',
            'keywords' => '',
            'canonical' => '',
            'og_tags' => [],
            'schema_markup' => ''
        ];
        
        try {
            \CModule::IncludeModule('iblock');
            
            // Получаем элемент
            $res = \CIBlockElement::GetList(
                [],
                ['ID' => $elementId, 'IBLOCK_ID' => $iblockId],
                false,
                false,
                ['ID', 'NAME', 'PREVIEW_TEXT', 'DETAIL_TEXT', 'IBLOCK_ID']
            );
            
            if ($element = $res->Fetch()) {
                // SEO свойства
                $seoProps = \CIBlockElement::GetList(
                    [],
                    ['ID' => $elementId],
                    false,
                    false,
                    ['ID', 'IBLOCK_ID']
                );
                
                $props = [];
                if ($seoProps) {
                    while ($prop = $seoProps->Fetch()) {
                        if (strpos($prop['CODE'], 'SEO') !== false) {
                            $props[$prop['CODE']] = $prop['VALUE'];
                        }
                    }
                }
                
                // Заголовок
                $metadata['title'] = $props['SEO_TITLE'] ?? \CIBlockElement::GetProperty(
                    $iblockId, 
                    $elementId, 
                    [], 
                    ['CODE' => 'SEO_TITLE']
                )->Fetch()['VALUE'] ?? $element['NAME'];
                
                // Описание
                $metadata['description'] = $props['SEO_DESCRIPTION'] ?? \CIBlockElement::GetProperty(
                    $iblockId, 
                    $elementId, 
                    [], 
                    ['CODE' => 'SEO_DESCRIPTION']
                )->Fetch()['VALUE'] ?? mb_substr(strip_tags($element['PREVIEW_TEXT']), 0, 160);
                
                // Ключевые слова
                $metadata['keywords'] = $props['SEO_KEYWORDS'] ?? \CIBlockElement::GetProperty(
                    $iblockId, 
                    $elementId, 
                    [], 
                    ['CODE' => 'SEO_KEYWORDS']
                )->Fetch()['VALUE'] ?? '';
                
                // Canonical URL
                $metadata['canonical'] = self::getCanonicalUrl($elementId, $iblockId);
                
                // Open Graph теги
                $metadata['og_tags'] = self::getOgTags($element, $iblockId);
                
                // Schema.org markup
                $metadata['schema_markup'] = self::getSchemaMarkup($element, $iblockId);
            }
            
        } catch (\Exception $e) {
            // Игнорируем ошибки
        }
        
        return $metadata;
    }
    
    /**
     * Получить canonical URL
     */
    private static function getCanonicalUrl(int $elementId, int $iblockId): string
    {
        try {
            $element = ElementTable::getList([
                'filter' => ['ID' => $elementId, 'IBLOCK_ID' => $iblockId],
                'select' => ['ID', 'IBLOCK_ID', 'DETAIL_PAGE_URL']
            ])->fetch();
            
            if ($element && !empty($element['DETAIL_PAGE_URL'])) {
                $context = \Bitrix\Main\Context::getCurrent();
                $scheme = $context->getRequest()->isHttps() ? 'https' : 'http';
                $host = $context->getServer()->getServerName();
                
                return $scheme . '://' . $host . $element['DETAIL_PAGE_URL'];
            }
        } catch (\Exception $e) {
            // Игнорируем
        }
        
        return '';
    }
    
    /**
     * Получить Open Graph теги
     */
    private static function getOgTags(array $element, int $iblockId): array
    {
        $tags = [
            'og:title' => $element['NAME'] ?? '',
            'og:description' => '',
            'og:url' => '',
            'og:type' => 'website',
            'og:image' => ''
        ];
        
        // Получаем картинку
        $res = \CIBlockElement::GetList(
            [],
            ['ID' => $element['ID']],
            false,
            false,
            ['ID', 'PREVIEW_PICTURE', 'DETAIL_PICTURE']
        );
        
        if ($el = $res->Fetch()) {
            $pictureId = $el['DETAIL_PICTURE'] ?: $el['PREVIEW_PICTURE'];
            
            if ($pictureId) {
                $picture = \CFile::GetFileArray($pictureId);
                if ($picture) {
                    $context = \Bitrix\Main\Context::getCurrent();
                    $scheme = $context->getRequest()->isHttps() ? 'https' : 'http';
                    $host = $context->getServer()->getServerName();
                    
                    $tags['og:image'] = $scheme . '://' . $host . $picture['SRC'];
                }
            }
        }
        
        return $tags;
    }
    
    /**
     * Получить Schema.org markup
     */
    private static function getSchemaMarkup(array $element, int $iblockId): string
    {
        // Проверяем настройки модуля
        $schemaType = Option::get(self::MODULE_ID, 'schema_type', '');
        
        if (empty($schemaType)) {
            return '';
        }
        
        // Пытаемся определить тип автоматически
        if ($schemaType === 'auto') {
            $schemaType = self::detectSchemaType($iblockId);
        }
        
        if (empty($schemaType)) {
            return '';
        }
        
        // Формируем JSON-LD
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => $schemaType,
            'name' => $element['NAME'] ?? '',
            'url' => self::getCanonicalUrl($element['ID'], $iblockId)
        ];
        
        // Добавляем описание
        if (!empty($element['PREVIEW_TEXT'])) {
            $schema['description'] = strip_tags($element['PREVIEW_TEXT']);
        }
        
        // JobPosting для вакансий
        if ($schemaType === 'JobPosting') {
            $props = \CIBlockElement::GetProperty(
                $iblockId, 
                $element['ID'], 
                [], 
                ['CODE' => 'JOBSALARY', 'CODE' => 'JOBLOCATION', 'CODE' => 'EMPLOYMENT_TYPE']
            );
            
            while ($prop = $props->Fetch()) {
                if ($prop['CODE'] === 'JOBSALARY' && !empty($prop['VALUE'])) {
                    $schema['baseSalary'] = $prop['VALUE'];
                }
                if ($prop['CODE'] === 'JOBLOCATION' && !empty($prop['VALUE'])) {
                    $schema['jobLocation'] = ['@type' => 'Place', 'address' => $prop['VALUE']];
                }
                if ($prop['CODE'] === 'EMPLOYMENT_TYPE' && !empty($prop['VALUE'])) {
                    $schema['employmentType'] = $prop['VALUE'];
                }
            }
        }
        
        // BroadcastEvent для видео
        if ($schemaType === 'BroadcastEvent') {
            $props = \CIBlockElement::GetProperty(
                $iblockId, 
                $element['ID'], 
                [], 
                ['CODE' => 'VIDEODURATION', 'CODE' => 'VIDEOCONTENTURL']
            );
            
            while ($prop = $props->Fetch()) {
                if ($prop['CODE'] === 'VIDEODURATION' && !empty($prop['VALUE'])) {
                    $schema['duration'] = 'PT' . $prop['VALUE'] . 'M';
                }
                if ($prop['CODE'] === 'VIDEOCONTENTURL' && !empty($prop['VALUE'])) {
                    $schema['contentUrl'] = $prop['VALUE'];
                }
            }
        }
        
        return json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
    /**
     * Определить тип Schema автоматически
     */
    private static function detectSchemaType(int $iblockId): string
    {
        try {
            \CModule::IncludeModule('iblock');
            
            $iblock = \CIBlock::GetByID($iblockId)->Fetch();
            
            if ($iblock) {
                $name = strtolower($iblock['NAME']);
                
                // Вакансии
                if (strpos($name, 'vacanc') !== false || strpos($name, 'работ') !== false) {
                    return 'JobPosting';
                }
                
                // Видео
                if (strpos($name, 'video') !== false || strpos($name, 'видео') !== false) {
                    return 'BroadcastEvent';
                }
                
                // Новости
                if (strpos($name, 'news') !== false || strpos($name, 'новост') !== false) {
                    return 'NewsArticle';
                }
                
                // Статьи
                if (strpos($name, 'article') !== false || strpos($name, 'стать') !== false) {
                    return 'Article';
                }
                
                // Товары
                if (strpos($name, 'product') !== false || strpos($name, 'товар') !== false) {
                    return 'Product';
                }
            }
        } catch (\Exception $e) {
            // Игнорируем
        }
        
        return '';
    }
    
    /**
     * Проверить наличие Schema разметки
     */
    public static function hasSchemaMarkup(int $elementId, int $iblockId): bool
    {
        return !empty(self::getSchemaMarkup(['ID' => $elementId], $iblockId));
    }
    
    /**
     * Генерировать HTML теги для HEAD
     */
    public static function generateHeadTags(int $elementId, int $iblockId): string
    {
        $metadata = self::getElementMetadata($elementId, $iblockId);
        $html = '';
        
        // Title
        if (!empty($metadata['title'])) {
            $html .= '<title>' . htmlspecialchars($metadata['title']) . '</title>' . "\n";
        }
        
        // Meta теги
        if (!empty($metadata['description'])) {
            $html .= '<meta name="description" content="' . htmlspecialchars($metadata['description']) . '">' . "\n";
        }
        
        if (!empty($metadata['keywords'])) {
            $html .= '<meta name="keywords" content="' . htmlspecialchars($metadata['keywords']) . '">' . "\n";
        }
        
        // Canonical
        if (!empty($metadata['canonical'])) {
            $html .= '<link rel="canonical" href="' . htmlspecialchars($metadata['canonical']) . '">' . "\n";
        }
        
        // Open Graph
        foreach ($metadata['og_tags'] as $property => $content) {
            if (!empty($content)) {
                $html .= '<meta property="' . $property . '" content="' . htmlspecialchars($content) . '">' . "\n";
            }
        }
        
        // Schema.org JSON-LD
        if (!empty($metadata['schema_markup'])) {
            $html .= '<script type="application/ld+json">' . "\n";
            $html .= $metadata['schema_markup'] . "\n";
            $html .= '</script>' . "\n";
        }
        
        return $html;
    }
}
