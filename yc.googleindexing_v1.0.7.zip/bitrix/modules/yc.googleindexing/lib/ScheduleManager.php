<?php
/**
 * Schedule Manager - Планировщик задач для Indexing API
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Config\Option;
use Bitrix\Main\Application;

class ScheduleManager
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Доступные типы расписания
     */
    const SCHEDULE_REALTIME = 'realtime';
    const SCHEDULE_HOURLY = 'hourly';
    const SCHEDULE_DAILY = 'daily';
    const SCHEDULE_WEEKLY = 'weekly';
    const SCHEDULE_CUSTOM = 'custom';
    
    /**
     * Получить текущее расписание
     */
    public static function getSchedule(): array
    {
        return [
            'type' => Option::get(self::MODULE_ID, 'schedule_type', self::SCHEDULE_REALTIME),
            'hour' => (int)Option::get(self::MODULE_ID, 'schedule_hour', 0),
            'minute' => (int)Option::get(self::MODULE_ID, 'schedule_minute', 0),
            'day_of_week' => (int)Option::get(self::MODULE_ID, 'schedule_day_of_week', 1),
            'custom_interval' => (int)Option::get(self::MODULE_ID, 'schedule_custom_interval', 300),
            'enabled' => Option::get(self::MODULE_ID, 'schedule_enabled', 'Y') === 'Y'
        ];
    }
    
    /**
     * Сохранить расписание
     */
    public static function setSchedule(array $schedule): bool
    {
        Option::set(self::MODULE_ID, 'schedule_type', $schedule['type']);
        Option::set(self::MODULE_ID, 'schedule_enabled', $schedule['enabled'] ? 'Y' : 'N');
        
        if (isset($schedule['hour'])) {
            Option::set(self::MODULE_ID, 'schedule_hour', $schedule['hour']);
        }
        
        if (isset($schedule['minute'])) {
            Option::set(self::MODULE_ID, 'schedule_minute', $schedule['minute']);
        }
        
        if (isset($schedule['day_of_week'])) {
            Option::set(self::MODULE_ID, 'schedule_day_of_week', $schedule['day_of_week']);
        }
        
        if (isset($schedule['custom_interval'])) {
            Option::set(self::MODULE_ID, 'schedule_custom_interval', $schedule['custom_interval']);
        }
        
        // Перерегистрировать агент
        self::registerAgent();
        
        return true;
    }
    
    /**
     * Зарегистрировать агент согласно расписанию
     */
    public static function registerAgent(): bool
    {
        $schedule = self::getSchedule();
        
        // Удаляем старый агент
        \CAgent::RemoveModuleAgents(self::MODULE_ID);
        
        if (!$schedule['enabled']) {
            return true;
        }
        
        // Интервал в секундах
        $interval = self::calculateInterval($schedule);
        
        \CAgent::AddAgent(
            "\\Yc\\GoogleIndexing\\Agent::sendQueue();",
            self::MODULE_ID,
            "N",
            $interval,
            "",
            "Y",
            ""
        );
        
        return true;
    }
    
    /**
     * Вычислить интервал в секундах
     */
    private static function calculateInterval(array $schedule): int
    {
        switch ($schedule['type']) {
            case self::SCHEDULE_REALTIME:
                return 60; // Каждую минуту
                
            case self::SCHEDULE_HOURLY:
                return 3600; // Каждый час
                
            case self::SCHEDULE_DAILY:
                // Вычисляем секунды до следующего запуска
                $now = new \DateTime();
                $target = new \DateTime();
                $target->setTime($schedule['hour'], $schedule['minute'], 0);
                
                if ($target <= $now) {
                    $target->modify('+1 day');
                }
                
                return $target->getTimestamp() - $now->getTimestamp();
                
            case self::SCHEDULE_WEEKLY:
                $now = new \DateTime();
                $target = new \DateTime();
                $target->setTime($schedule['hour'], $schedule['minute'], 0);
                $target->setISODate(
                    $now->format('Y'), 
                    $now->format('W'), 
                    $schedule['day_of_week']
                );
                
                if ($target <= $now) {
                    $target->modify('+1 week');
                }
                
                return $target->getTimestamp() - $now->getTimestamp();
                
            case self::SCHEDULE_CUSTOM:
            default:
                return max(60, $schedule['custom_interval']);
        }
    }
    
    /**
     * Получить следующее время запуска
     */
    public static function getNextRun(): ?\DateTime
    {
        $schedule = self::getSchedule();
        
        if (!$schedule['enabled']) {
            return null;
        }
        
        $now = new \DateTime();
        
        switch ($schedule['type']) {
            case self::SCHEDULE_REALTIME:
                return (clone $now)->modify('+1 minute');
                
            case self::SCHEDULE_HOURLY:
                return (clone $now)->modify('+1 hour');
                
            case self::SCHEDULE_DAILY:
                $next = new \DateTime();
                $next->setTime($schedule['hour'], $schedule['minute'], 0);
                
                if ($next <= $now) {
                    $next->modify('+1 day');
                }
                
                return $next;
                
            case self::SCHEDULE_WEEKLY:
                $next = new \DateTime();
                $next->setTime($schedule['hour'], $schedule['minute'], 0);
                $next->setISODate($now->format('Y'), $now->format('W'), $schedule['day_of_week']);
                
                if ($next <= $now) {
                    $next->modify('+1 week');
                }
                
                return $next;
                
            case self::SCHEDULE_CUSTOM:
                return (clone $now)->modify('+' . $schedule['custom_interval'] . ' seconds');
                
            default:
                return null;
        }
    }
    
    /**
     * Получить расписание в читаемом формате
     */
    public static function getScheduleText(): string
    {
        $schedule = self::getSchedule();
        
        if (!$schedule['enabled']) {
            return 'Отключено';
        }
        
        switch ($schedule['type']) {
            case self::SCHEDULE_REALTIME:
                return 'В реальном времени (каждую минуту)';
                
            case self::SCHEDULE_HOURLY:
                return 'Ежечасно';
                
            case self::SCHEDULE_DAILY:
                return sprintf(
                    'Ежедневно в %02d:%02d',
                    $schedule['hour'],
                    $schedule['minute']
                );
                
            case self::SCHEDULE_WEEKLY:
                $days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
                $dayName = $days[$schedule['day_of_week'] - 1] ?? 'Понедельник';
                
                return sprintf(
                    'Еженедельно в %s %02d:%02d',
                    $dayName,
                    $schedule['hour'],
                    $schedule['minute']
                );
                
            case self::SCHEDULE_CUSTOM:
                return 'Каждые ' . $schedule['custom_interval'] . ' секунд';
                
            default:
                return 'Неизвестно';
        }
    }
    
    /**
     * Создать запланированную задачу
     */
    public static function createTask(string $url, string $type, \DateTime $runTime): int
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            INSERT INTO b_yc_gindex_schedule (URL, TYPE, RUN_TIME, STATUS)
            VALUES (
                '" . $connection->getSqlHelper()->forSql($url) . "',
                '" . $connection->getSqlHelper()->forSql($type) . "',
                '" . $runTime->format('Y-m-d H:i:s') . "',
                'PENDING'
            )
        ");
        
        return $connection->getInsertedId();
    }
    
    /**
     * Выполнить запланированные задачи
     */
    public static function executeScheduledTasks(): int
    {
        $connection = Application::getConnection();
        
        // Получаем задачи для выполнения
        $result = $connection->query("
            SELECT * FROM b_yc_gindex_schedule
            WHERE STATUS = 'PENDING'
            AND RUN_TIME <= NOW()
            LIMIT 100
        ");
        
        $executed = 0;
        
        while ($task = $result->fetch()) {
            try {
                // Добавляем в очередь
                QueueTable::add([
                    'URL' => $task['URL'],
                    'TYPE' => $task['TYPE'],
                    'STATUS' => 'NEW',
                    'PRIORITY' => 'MEDIUM',
                    'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
                ]);
                
                // Обновляем статус
                $connection->query("
                    UPDATE b_yc_gindex_schedule
                    SET STATUS = 'EXECUTED',
                        EXECUTED_AT = NOW()
                    WHERE ID = " . $task['ID']
                );
                
                $executed++;
                
            } catch (\Exception $e) {
                // Логируем ошибку
                $connection->query("
                    UPDATE b_yc_gindex_schedule
                    SET STATUS = 'ERROR',
                        ERROR_MESSAGE = '" . $connection->getSqlHelper()->forSql($e->getMessage()) . "'
                    WHERE ID = " . $task['ID']
                );
            }
        }
        
        return $executed;
    }
    
    /**
     * Удалить старые выполненные задачи
     */
    public static function cleanupOldTasks(int $days = 30): int
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            DELETE FROM b_yc_gindex_schedule
            WHERE STATUS IN ('EXECUTED', 'ERROR')
            AND EXECUTED_AT < DATE_SUB(NOW(), INTERVAL " . intval($days) . " DAY)
        ");
        
        return $result->getAffectedRowsCount();
    }
    
    /**
     * Получить статистику запланированных задач
     */
    public static function getScheduledStats(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT STATUS, COUNT(*) as CNT
            FROM b_yc_gindex_schedule
            GROUP BY STATUS
        ");
        
        $stats = [
            'PENDING' => 0,
            'EXECUTED' => 0,
            'ERROR' => 0
        ];
        
        while ($row = $result->fetch()) {
            $stats[$row['STATUS']] = (int)$row['CNT'];
        }
        
        return $stats;
    }
}
