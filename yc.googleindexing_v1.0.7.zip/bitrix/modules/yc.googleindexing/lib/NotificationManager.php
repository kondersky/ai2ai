<?php
/**
 * Notification Manager - Менеджер уведомлений
 * Поддержка Email, Telegram, Slack уведомлений
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Config\Option;
use Bitrix\Main\Mail\Event;

class NotificationManager
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Отправить уведомление об успешной отправке
     */
    public static function onUrlSent(array $queueItem, array $apiResponse): void
    {
        if (Option::get(self::MODULE_ID, 'notify_on_success', 'N') !== 'Y') {
            return;
        }
        
        $message = sprintf(
            "URL успешно отправлен в Google Indexing API:\n%s\n\nТип: %s\nСтатус: %s",
            $queueItem['URL'],
            $queueItem['TYPE'],
            $apiResponse['http_code'] ?? 'unknown'
        );
        
        self::sendNotifications($message, 'Успешная отправка URL');
    }
    
    /**
     * Отправить уведомление об ошибке
     */
    public static function onError(array $queueItem, string $error): void
    {
        if (Option::get(self::MODULE_ID, 'notify_on_error', 'Y') !== 'Y') {
            return;
        }
        
        $message = sprintf(
            "Ошибка отправки URL в Google Indexing API:\n%s\n\nОшибка: %s\nПопыток: %d",
            $queueItem['URL'] ?? 'Unknown',
            $error,
            $queueItem['ATTEMPTS'] ?? 0
        );
        
        self::sendNotifications($message, 'Ошибка отправки URL', 'error');
    }
    
    /**
     * Отправить уведомление о достижении лимита
     */
    public static function onQuotaExceeded(int $sent, int $limit): void
    {
        $message = sprintf(
            "Достигнут дневной лимит отправки в Google Indexing API:\n\nОтправлено: %d\nЛимит: %d\nОсталось: %d",
            $sent,
            $limit,
            max(0, $limit - $sent)
        );
        
        self::sendNotifications($message, 'Достигнут лимит квоты', 'warning');
    }
    
    /**
     * Отправить уведомление о сбросе квоты
     */
    public static function onQuotaReset(int $previousSent): void
    {
        if ($previousSent > 0 && Option::get(self::MODULE_ID, 'notify_on_quota_reset', 'Y') === 'Y') {
            $message = sprintf(
                "Квота Google Indexing API сброшена:\n\nПредыдущий день: %d URL",
                $previousSent
            );
            
            self::sendNotifications($message, 'Квота сброшена', 'info');
        }
    }
    
    /**
     * Отправить уведомление об изменении настроек
     */
    public static function onSettingsChanged(string $setting, $oldValue, $newValue): void
    {
        if (Option::get(self::MODULE_ID, 'notify_on_settings', 'N') !== 'Y') {
            return;
        }
        
        $message = sprintf(
            "Изменены настройки модуля Google Indexing API:\n\nНастройка: %s\nБыло: %s\nСтало: %s",
            $setting,
            $oldValue,
            $newValue
        );
        
        self::sendNotifications($message, 'Изменены настройки модуля', 'info');
    }
    
    /**
     * Основная функция отправки уведомлений
     */
    private static function sendNotifications(string $message, string $subject, string $type = 'info'): void
    {
        // Email уведомление
        if (Option::get(self::MODULE_ID, 'notify_email', '') !== '') {
            self::sendEmail($subject, $message);
        }
        
        // Telegram уведомление
        if (Option::get(self::MODULE_ID, 'notify_telegram', 'N') === 'Y') {
            self::sendTelegram($message);
        }
        
        // Slack уведомление
        if (Option::get(self::MODULE_ID, 'notify_slack', 'N') === 'Y') {
            self::sendSlack($message, $subject, $type);
        }
    }
    
    /**
     * Отправить Email
     */
    private static function sendEmail(string $subject, string $message): void
    {
        $email = Option::get(self::MODULE_ID, 'notify_email', '');
        
        if (empty($email)) {
            return;
        }
        
        $headers = "From: noreply@" . $_SERVER['SERVER_NAME'] . "\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\n";
        
        @mail($email, $subject, $message, $headers);
    }
    
    /**
     * Отправить Telegram
     */
    private static function sendTelegram(string $message): void
    {
        $token = Option::get(self::MODULE_ID, 'telegram_token', '');
        $chatId = Option::get(self::MODULE_ID, 'telegram_chat_id', '');
        
        if (empty($token) || empty($chatId)) {
            return;
        }
        
        $text = "📢 *Google Indexing API PRO*\n\n" . $message;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot{$token}/sendMessage");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'Markdown'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    }
    
    /**
     * Отправить Slack
     */
    private static function sendSlack(string $message, string $subject, string $type): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'slack_webhook', '');
        
        if (empty($webhookUrl)) {
            return;
        }
        
        $colors = [
            'info' => '#36a64f',
            'warning' => '#ff9800',
            'error' => '#f44336'
        ];
        
        $payload = json_encode([
            'attachments' => [
                [
                    'color' => $colors[$type] ?? '#36a64f',
                    'title' => $subject,
                    'text' => $message,
                    'footer' => 'Google Indexing API PRO',
                    'ts' => time()
                ]
            ]
        ]);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhookUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);
    }
    
    /**
     * Тестовая отправка всех уведомлений
     */
    public static function testNotifications(): array
    {
        $results = [
            'email' => false,
            'telegram' => false,
            'slack' => false
        ];
        
        // Тест Email
        $email = Option::get(self::MODULE_ID, 'notify_email', '');
        if (!empty($email)) {
            self::sendEmail('Test', 'Test message from Google Indexing API PRO');
            $results['email'] = true;
        }
        
        // Тест Telegram
        $token = Option::get(self::MODULE_ID, 'telegram_token', '');
        if (!empty($token)) {
            self::sendTelegram('Test message from Google Indexing API PRO');
            $results['telegram'] = true;
        }
        
        // Тест Slack
        $webhook = Option::get(self::MODULE_ID, 'slack_webhook', '');
        if (!empty($webhook)) {
            self::sendSlack('Test message', 'Test', 'info');
            $results['slack'] = true;
        }
        
        return $results;
    }
}
