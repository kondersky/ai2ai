<?php
/**
 * REST API для внешних систем
 * Позволяет управлять очередью извне
 * 
 * Endpoints:
 * - GET /api/v1/queue - получить очередь
 * - POST /api/v1/queue - добавить URL в очередь
 * - DELETE /api/v1/queue/{id} - удалить из очереди
 * - GET /api/v1/stats - получить статистику
 * - POST /api/v1/test - тест API
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;

class RestApi
{
    private const MODULE_ID = 'yc.googleindexing';
    private const API_VERSION = 'v1';
    
    private $apiKey;
    private $method;
    private $path;
    private $params;
    
    public function __construct()
    {
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->parsePath();
        $this->params = array_merge($_GET, $_POST);
    }
    
    /**
     * Запустить API
     */
    public function run(): void
    {
        // Проверка API ключа
        if (!$this->authenticate()) {
            $this->error(401, 'Unauthorized', 'Invalid or missing API key');
            return;
        }
        
        // Маршрутизация
        try {
            switch ($this->path) {
                case '/api/' . self::API_VERSION . '/queue':
                    $this->handleQueue();
                    break;
                    
                case '/api/' . self::API_VERSION . '/stats':
                    $this->handleStats();
                    break;
                    
                case '/api/' . self::API_VERSION . '/test':
                    $this->handleTest();
                    break;
                    
                case '/api/' . self::API_VERSION . '/quota':
                    $this->handleQuota();
                    break;
                    
                case '/api/' . self::API_VERSION . '/logs':
                    $this->handleLogs();
                    break;
                    
                case '/api/' . self::API_VERSION . '/settings':
                    $this->handleSettings();
                    break;
                    
                case '/api/' . self::API_VERSION . '/force-send':
                    $this->handleForceSend();
                    break;
                    
                default:
                    $this->error(404, 'Not Found', 'Endpoint not found');
            }
        } catch (\Exception $e) {
            $this->error(500, 'Internal Error', $e->getMessage());
        }
    }
    
    /**
     * Аутентификация
     */
    private function authenticate(): bool
    {
        // Проверка через заголовок Authorization
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (preg_match('/Bearer\s+(.+)/i', $authHeader, $matches)) {
            $token = $matches[1];
        } else {
            // Проверка через параметр
            $token = $this->params['api_key'] ?? '';
        }
        
        if (empty($token)) {
            return false;
        }
        
        // Получить сохранённый API ключ
        $savedKey = Option::get(self::MODULE_ID, 'rest_api_key', '');
        
        // Также поддерживаем временный ключ для разработки
        $devKey = Option::get(self::MODULE_ID, 'rest_api_dev_key', '');
        
        return $token === $savedKey || $token === $devKey;
    }
    
    /**
     * Обработка очереди
     */
    private function handleQueue(): void
    {
        switch ($this->method) {
            case 'GET':
                $this->getQueue();
                break;
            case 'POST':
                $this->addToQueue();
                break;
            case 'DELETE':
                $this->deleteFromQueue();
                break;
            default:
                $this->error(405, 'Method Not Allowed');
        }
    }
    
    /**
     * Получить список URL в очереди
     */
    private function getQueue(): void
    {
        $limit = (int)($this->params['limit'] ?? 50);
        $offset = (int)($this->params['offset'] ?? 0);
        $status = $this->params['status'] ?? '';
        
        $filter = [];
        if (!empty($status)) {
            $filter['STATUS'] = $status;
        }
        
        $queue = QueueTable::getList($limit, $offset, $filter);
        
        $this->success([
            'items' => $queue,
            'limit' => $limit,
            'offset' => $offset,
            'total' => count($queue)
        ]);
    }
    
    /**
     * Добавить URL в очередь
     */
    private function addToQueue(): void
    {
        $url = $this->params['url'] ?? '';
        $type = $this->params['type'] ?? 'URL_UPDATED';
        $iblockId = (int)($this->params['iblock_id'] ?? 0);
        $elementId = (int)($this->params['element_id'] ?? 0);
        $priority = $this->params['priority'] ?? 'MEDIUM';
        
        if (empty($url)) {
            $this->error(400, 'Bad Request', 'URL is required');
            return;
        }
        
        // Валидация URL
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            $this->error(400, 'Bad Request', 'Invalid URL format');
            return;
        }
        
        // Валидация типа
        if (!in_array($type, ['URL_UPDATED', 'URL_DELETED'])) {
            $type = 'URL_UPDATED';
        }
        
        // Валидация приоритета
        if (!in_array($priority, ['LOW', 'MEDIUM', 'HIGH'])) {
            $priority = 'MEDIUM';
        }
        
        try {
            $id = QueueTable::add([
                'URL' => $url,
                'TYPE' => $type,
                'STATUS' => 'NEW',
                'PRIORITY' => $priority,
                'IBLOCK_ID' => $iblockId > 0 ? $iblockId : null,
                'ELEMENT_ID' => $elementId > 0 ? $elementId : null,
                'DATE_CREATE' => new \Bitrix\Main\DB\SqlExpression('NOW()')
            ]);
            
            $this->success([
                'id' => $id,
                'message' => 'URL added to queue'
            ], 201);
            
        } catch (\Exception $e) {
            $this->error(500, 'Internal Error', $e->getMessage());
        }
    }
    
    /**
     * Удалить из очереди
     */
    private function deleteFromQueue(): void
    {
        $id = (int)($this->params['id'] ?? 0);
        
        if ($id <= 0) {
            // Можно удалять по URL
            $url = $this->params['url'] ?? '';
            if (empty($url)) {
                $this->error(400, 'Bad Request', 'ID or URL is required');
                return;
            }
            
            $connection = Application::getConnection();
            $connection->query("
                DELETE FROM b_yc_gindex_queue 
                WHERE URL = '" . $connection->getSqlHelper()->forSql($url) . "'
            ");
            
            $this->success(['message' => 'URL removed from queue']);
            return;
        }
        
        $connection = Application::getConnection();
        $connection->query("
            DELETE FROM b_yc_gindex_queue 
            WHERE ID = " . $id
        );
        
        $this->success(['message' => 'Item removed from queue']);
    }
    
    /**
     * Обработка статистики
     */
    private function handleStats(): void
    {
        $stats = Analytics::getSummaryReport();
        $this->success($stats);
    }
    
    /**
     * Обработка квоты
     */
    private function handleQuota(): void
    {
        $quota = QuotaTable::getStatus();
        $this->success($quota);
    }
    
    /**
     * Обработка логов
     */
    private function handleLogs(): void
    {
        $limit = (int)($this->params['limit'] ?? 50);
        $logs = LogTable::getList($limit);
        $this->success(['items' => $logs]);
    }
    
    /**
     * Обработка настроек
     */
    private function handleSettings(): void
    {
        if ($this->method === 'GET') {
            // Получить настройки
            $settings = [
                'daily_limit' => (int)Option::get(self::MODULE_ID, 'daily_limit', 200),
                'batch_size' => (int)Option::get(self::MODULE_ID, 'batch_size', 50),
                'enable_sections' => Option::get(self::MODULE_ID, 'enable_sections', 'N'),
                'enable_webhook' => Option::get(self::MODULE_ID, 'enable_webhook', 'N'),
                'webhook_url' => !empty(Option::get(self::MODULE_ID, 'webhook_url', '')),
                'has_credentials' => CredentialsTable::getCredentials() !== null,
                'api_enabled' => Option::get(self::MODULE_ID, 'rest_api_enabled', 'N')
            ];
            $this->success($settings);
            return;
        }
        
        if ($this->method === 'POST') {
            // Сохранить настройки
            foreach ($this->params as $key => $value) {
                if (in_array($key, ['daily_limit', 'batch_size', 'enable_sections', 'enable_webhook', 'webhook_url', 'rest_api_enabled'])) {
                    Option::set(self::MODULE_ID, $key, $value);
                }
            }
            $this->success(['message' => 'Settings updated']);
            return;
        }
        
        $this->error(405, 'Method Not Allowed');
    }
    
    /**
     * Принудительная отправка (запуск агента)
     */
    private function handleForceSend(): void
    {
        if ($this->method !== 'POST') {
            $this->error(405, 'Method Not Allowed');
            return;
        }
        
        $apiKey = Option::get(self::MODULE_ID, 'rest_api_key', '');
        $devKey = Option::get(self::MODULE_ID, 'rest_api_dev_key', '');
        
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (preg_match('/Bearer\s+(.+)/i', $authHeader, $matches)) {
            $token = $matches[1];
        } else {
            $token = $this->params['api_key'] ?? '';
        }
        
        // Только полный API ключ может запускать принудительную отправку
        if ($token !== $apiKey) {
            $this->error(403, 'Forbidden', 'Full API key required for force send');
            return;
        }
        
        // Запустить агент
        $result = Agent::sendQueue();
        
        $this->success([
            'message' => 'Agent executed',
            'result' => $result
        ]);
    }
    
    /**
     * Тест API
     */
    private function handleTest(): void
    {
        $this->success([
            'status' => 'ok',
            'version' => '1.0.6',
            'timestamp' => date('c'),
            'module' => 'Google Indexing API PRO'
        ]);
    }
    
    /**
     * Разбор пути
     */
    private function parsePath(): void
    {
        $requestUri = $_SERVER['REQUEST_URI'];
        $parsed = parse_url($requestUri);
        $this->path = $parsed['path'] ?? '/';
    }
    
    /**
     * Успешный ответ
     */
    private function success($data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Ошибка
     */
    private function error(int $code, string $title, string $message = ''): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false,
            'error' => [
                'code' => $code,
                'message' => $title . ($message ? ': ' . $message : '')
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/**
 * Регистрация обработчика API
 * Вызывается из /api/index.php
 */
function handleGoogleIndexingApi(): void
{
    if (preg_match('/^\/api\/yc_googleindexing/', $_SERVER['REQUEST_URI'])) {
        Loader::includeModule('yc.googleindexing');
        
        $api = new RestApi();
        $api->run();
    }
}
