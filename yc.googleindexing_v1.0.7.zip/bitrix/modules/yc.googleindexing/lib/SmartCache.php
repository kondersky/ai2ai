<?php
/**
 * Smart Cache - Умное кэширование для API запросов
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;

class SmartCache
{
    private const MODULE_ID = 'yc.googleindexing';
    
    private static $cache = [];
    private static $cacheDir;
    private static $enabled = true;
    private static $ttl = 3600; // 1 час по умолчанию
    
    /**
     * Инициализация
     */
    public static function init(): void
    {
        self::$enabled = Option::get(self::MODULE_ID, 'enable_cache', 'Y') === 'Y';
        self::$ttl = (int)Option::get(self::MODULE_ID, 'cache_ttl', 3600);
        self::$cacheDir = Application::getDocumentRoot() . '/bitrix/cache/yc_googleindexing/';
        
        if (self::$enabled && !is_dir(self::$cacheDir)) {
            mkdir(self::$cacheDir, 0755, true);
        }
    }
    
    /**
     * Получить значение из кэша
     */
    public static function get(string $key, $default = null)
    {
        if (!self::$enabled) {
            return $default;
        }
        
        // Проверяем память
        if (isset(self::$cache[$key])) {
            $item = self::$cache[$key];
            if ($item['expire'] > time()) {
                return $item['value'];
            }
            unset(self::$cache[$key]);
        }
        
        // Проверяем файл
        $file = self::getCacheFile($key);
        if (file_exists($file)) {
            $content = file_get_contents($file);
            $data = @unserialize($content);
            
            if ($data && $data['expire'] > time()) {
                self::$cache[$key] = $data;
                return $data['value'];
            }
            
            @unlink($file);
        }
        
        return $default;
    }
    
    /**
     * Установить значение в кэш
     */
    public static function set(string $key, $value, int $ttl = 0): void
    {
        if (!self::$enabled) {
            return;
        }
        
        $ttl = $ttl > 0 ? $ttl : self::$ttl;
        $expire = time() + $ttl;
        
        $data = [
            'value' => $value,
            'expire' => $expire
        ];
        
        // Сохраняем в память
        self::$cache[$key] = $data;
        
        // Сохраняем в файл
        $file = self::getCacheFile($key);
        @file_put_contents($file, serialize($data), LOCK_EX);
    }
    
    /**
     * Удалить из кэша
     */
    public static function delete(string $key): void
    {
        unset(self::$cache[$key]);
        
        $file = self::$getCacheFile($key);
        if (file_exists($file)) {
            @unlink($file);
        }
    }
    
    /**
     * Очистить весь кэш
     */
    public static function clear(): void
    {
        self::$cache = [];
        
        if (is_dir(self::$cacheDir)) {
            $files = glob(self::$cacheDir . '*.php');
            foreach ($files as $file) {
                @unlink($file);
            }
        }
    }
    
    /**
     * Получить файл кэша
     */
    private static function getCacheFile(string $key): string
    {
        $hash = md5($key);
        return self::$cacheDir . $hash . '.php';
    }
    
    /**
     * Кэшировать результат функции
     */
    public static function remember(string $key, int $ttl, callable $callback)
    {
        $value = self::get($key);
        
        if ($value !== null) {
            return $value;
        }
        
        $value = $callback();
        self::set($key, $value, $ttl);
        
        return $value;
    }
    
    /**
     * Получить статистику кэша
     */
    public static function getStats(): array
    {
        $files = glob(self::$cacheDir . '*.php');
        $totalSize = 0;
        $expired = 0;
        $valid = 0;
        
        foreach ($files as $file) {
            $totalSize += filesize($file);
            $content = file_get_contents($file);
            $data = @unserialize($content);
            
            if ($data && $data['expire'] > time()) {
                $valid++;
            } else {
                $expired++;
            }
        }
        
        return [
            'enabled' => self::$enabled,
            'files' => count($files),
            'valid' => $valid,
            'expired' => $expired,
            'size_bytes' => $totalSize,
            'size_human' => round($totalSize / 1024, 2) . ' KB'
        ];
    }
}
