<?php
/**
 * Webhook Manager - Отправка уведомлений о событиях
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Config\Option;

class WebhookManager
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Отправить уведомление при успешной отправке
     */
    public static function onUrlSent(array $queueItem, array $apiResponse): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'webhook_url', '');
        if (empty($webhookUrl)) {
            return;
        }
        
        $payload = [
            'event' => 'url_sent',
            'timestamp' => date('c'),
            'data' => [
                'url' => $queueItem['URL'],
                'type' => $queueItem['TYPE'],
                'iblock_id' => $queueItem['IBLOCK_ID'],
                'element_id' => $queueItem['ELEMENT_ID'],
                'http_code' => $apiResponse['http_code'] ?? 0,
                'status' => $apiResponse['success'] ? 'success' : 'error'
            ]
        ];
        
        self::send($webhookUrl, $payload);
    }
    
    /**
     * Отправить уведомление при ошибке
     */
    public static function onError(array $queueItem, string $error): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'webhook_url', '');
        if (empty($webhookUrl)) {
            return;
        }
        
        $payload = [
            'event' => 'url_error',
            'timestamp' => date('c'),
            'data' => [
                'url' => $queueItem['URL'] ?? '',
                'error' => $error,
                'attempts' => $queueItem['ATTEMPTS'] ?? 0
            ]
        ];
        
        self::send($webhookUrl, $payload);
    }
    
    /**
     * Отправить уведомление при достижении лимита квоты
     */
    public static function onQuotaExceeded(int $sent, int $limit): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'webhook_url', '');
        if (empty($webhookUrl)) {
            return;
        }
        
        $payload = [
            'event' => 'quota_exceeded',
            'timestamp' => date('c'),
            'data' => [
                'sent' => $sent,
                'limit' => $limit,
                'message' => "Daily quota exceeded: {$sent}/{$limit}"
            ]
        ];
        
        self::send($webhookUrl, $payload);
    }
    
    /**
     * Отправить уведомление об окончании квоты
     */
    public static function onQuotaReset(): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'webhook_url', '');
        if (empty($webhookUrl)) {
            return;
        }
        
        $payload = [
            'event' => 'quota_reset',
            'timestamp' => date('c'),
            'data' => [
                'message' => 'Daily quota has been reset'
            ]
        ];
        
        self::send($webhookUrl, $payload);
    }
    
    /**
     * Отправить уведомление об изменении элемента
     */
    public static function onElementChanged(string $eventType, array $element): void
    {
        $webhookUrl = Option::get(self::MODULE_ID, 'webhook_url', '');
        if (empty($webhookUrl)) {
            return;
        }
        
        $payload = [
            'event' => 'element_' . $eventType,
            'timestamp' => date('c'),
            'data' => [
                'iblock_id' => $element['IBLOCK_ID'] ?? 0,
                'element_id' => $element['ID'] ?? 0,
                'name' => $element['NAME'] ?? '',
                'url' => $element['DETAIL_PAGE_URL'] ?? ''
            ]
        ];
        
        self::send($webhookUrl, $payload);
    }
    
    /**
     * Тестовая отправка webhook
     */
    public static function testWebhook(string $webhookUrl): array
    {
        $payload = [
            'event' => 'test',
            'timestamp' => date('c'),
            'data' => [
                'message' => 'Test webhook from Google Indexing API PRO',
                'module_version' => '1.0.6'
            ]
        ];
        
        return self::send($webhookUrl, $payload);
    }
    
    /**
     * Основная функция отправки
     */
    private static function send(string $url, array $payload): array
    {
        try {
            $ch = curl_init();
            
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payload),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'User-Agent: Google-Indexing-API-PRO/1.0'
                ],
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CONNECTTIMEOUT => 10
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                return [
                    'success' => false,
                    'error' => $error,
                    'http_code' => 0
                ];
            }
            
            return [
                'success' => $httpCode >= 200 && $httpCode < 300,
                'http_code' => $httpCode,
                'response' => $response
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'http_code' => 0
            ];
        }
    }
}
