<?php
/**
 * URL Validator - Валидация и очистка URL перед отправкой
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Config\Option;

class UrlValidator
{
    private const MODULE_ID = 'yc.googleindexing';
    
    private $errors = [];
    private $warnings = [];
    
    /**
     * Валидировать URL
     */
    public function validate(string $url): bool
    {
        $this->errors = [];
        $this->warnings = [];
        
        // Базовая проверка
        if (empty($url)) {
            $this->errors[] = 'URL is empty';
            return false;
        }
        
        // Проверка формата
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            $this->errors[] = 'Invalid URL format';
            return false;
        }
        
        $parsed = parse_url($url);
        
        // Проверка схемы
        if (!isset($parsed['scheme']) || !in_array($parsed['scheme'], ['http', 'https'])) {
            $this->errors[] = 'URL must use http or https protocol';
            return false;
        }
        
        // Проверка хоста
        if (empty($parsed['host'])) {
            $this->errors[] = 'URL must have a host';
            return false;
        }
        
        // Проверка на локальный хост
        if ($this->isLocalHost($parsed['host'])) {
            $this->errors[] = 'Localhost URLs are not allowed';
            return false;
        }
        
        // Проверка на IP адрес
        if ($this->isIpAddress($parsed['host'])) {
            $this->warnings[] = 'URL uses IP address instead of domain';
        }
        
        // Проверка длины
        if (strlen($url) > 2048) {
            $this->warnings[] = 'URL is longer than 2048 characters (Google limit)';
        }
        
        // Проверка на недопустимые символы
        if ($this->hasInvalidChars($url)) {
            $this->warnings[] = 'URL contains potentially invalid characters';
        }
        
        // Проверка на дубли параметров
        if ($this->hasDuplicateParams($url)) {
            $this->warnings[] = 'URL has duplicate query parameters';
        }
        
        // Проверка на UTM метки (предупреждение)
        if ($this->hasUtmParams($url)) {
            $this->warnings[] = 'URL contains UTM parameters - they may be stripped';
        }
        
        // Проверка на сессионные ID
        if ($this->hasSessionId($url)) {
            $this->warnings[] = 'URL contains session ID - should be removed';
        }
        
        // Проверка доступности (опционально)
        if (Option::get(self::MODULE_ID, 'validate_url_check', 'N') === 'Y') {
            if (!$this->isReachable($url)) {
                $this->warnings[] = 'URL may not be reachable';
            }
        }
        
        return empty($this->errors);
    }
    
    /**
     * Очистить URL
     */
    public function clean(string $url): string
    {
        $parsed = parse_url($url);
        
        // Удаляем UTM параметры
        $url = $this->removeUtmParams($url);
        
        // Удаляем сессионные ID
        $url = $this->removeSessionId($url);
        
        // Удаляем дубли параметров
        $url = $this->removeDuplicateParams($url);
        
        // Удаляем пустые параметры
        $url = $this->removeEmptyParams($url);
        
        // Нормализуем URL
        $url = $this->normalize($url);
        
        return $url;
    }
    
    /**
     * Проверка на локальный хост
     */
    private function isLocalHost(string $host): bool
    {
        $localHosts = ['localhost', '127.0.0.1', '::1', '0.0.0.0'];
        return in_array(strtolower($host), $localHosts);
    }
    
    /**
     * Проверка на IP адрес
     */
    private function isIpAddress(string $host): bool
    {
        return filter_var($host, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * Проверка на недопустимые символы
     */
    private function hasInvalidChars(string $url): bool
    {
        // Проверяем на пробелы и управляющие символы
        return preg_match('/[\x00-\x1F\x7F]/', $url);
    }
    
    /**
     * Проверка на дубли параметров
     */
    private function hasDuplicateParams(string $url): bool
    {
        if (!isset(parse_url($url)['query'])) {
            return false;
        }
        
        parse_str(parse_url($url)['query'], $params);
        return count($params) !== count(array_unique($params));
    }
    
    /**
     * Проверка на UTM метки
     */
    private function hasUtmParams(string $url): bool
    {
        return preg_match('/utm_/i', $url);
    }
    
    /**
     * Проверка на сессионные ID
     */
    private function hasSessionId(string $url): bool
    {
        $sessionParams = ['PHPSESSID', 'session_id', 'sid', 'sessid'];
        parse_str(parse_url($url)['query'] ?? '', $params);
        
        foreach ($sessionParams as $param) {
            if (isset($params[$param])) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Удалить UTM параметры
     */
    private function removeUtmParams(string $url): string
    {
        return preg_replace('/[?&]utm_[^&]+/', '', $url);
    }
    
    /**
     * Удалить сессионные ID
     */
    private function removeSessionId(string $url): string
    {
        $sessionParams = ['PHPSESSID', 'session_id', 'sid', 'sessid', 'JSESSIONID'];
        
        $parsed = parse_url($url);
        parse_str($parsed['query'] ?? '', $params);
        
        foreach ($sessionParams as $param) {
            unset($params[$param]);
        }
        
        $parsed['query'] = http_build_query($params);
        
        // Удаляем пустой query
        if (empty($parsed['query'])) {
            unset($parsed['query']);
        }
        
        return $this->unparseUrl($parsed);
    }
    
    /**
     * Удалить дубли параметров
     */
    private function removeDuplicateParams(string $url): string
    {
        $parsed = parse_url($url);
        parse_str($parsed['query'] ?? '', $params);
        
        // Сохраняем только первое значение каждого параметра
        $params = array_unique($params);
        
        $parsed['query'] = http_build_query($params);
        
        if (empty($parsed['query'])) {
            unset($parsed['query']);
        }
        
        return $this->unparseUrl($parsed);
    }
    
    /**
     * Удалить пустые параметры
     */
    private function removeEmptyParams(string $url): string
    {
        $parsed = parse_url($url);
        parse_str($parsed['query'] ?? '', $params);
        
        $params = array_filter($params, function($value) {
            return $value !== '' && $value !== null;
        });
        
        $parsed['query'] = http_build_query($params);
        
        if (empty($parsed['query'])) {
            unset($parsed['query']);
        }
        
        return $this->unparseUrl($parsed);
    }
    
    /**
     * Нормализовать URL
     */
    private function normalize(string $url): string
    {
        $parsed = parse_url($url);
        
        // Удаляем trailing slash
        if (isset($parsed['path']) && $parsed['path'] !== '/') {
            $parsed['path'] = rtrim($parsed['path'], '/');
        }
        
        // Нижний регистр домена
        if (isset($parsed['host'])) {
            $parsed['host'] = strtolower($parsed['host']);
        }
        
        return $this->unparseUrl($parsed);
    }
    
    /**
     * Собрать URL из частей
     */
    private function unparseUrl(array $parsed): string
    {
        $url = '';
        
        if (isset($parsed['scheme'])) {
            $url .= $parsed['scheme'] . '://';
        }
        
        if (isset($parsed['user'])) {
            $url .= $parsed['user'];
            if (isset($parsed['pass'])) {
                $url .= ':' . $parsed['pass'];
            }
            $url .= '@';
        }
        
        if (isset($parsed['host'])) {
            $url .= $parsed['host'];
        }
        
        if (isset($parsed['port'])) {
            $url .= ':' . $parsed['port'];
        }
        
        if (isset($parsed['path'])) {
            $url .= $parsed['path'];
        }
        
        if (isset($parsed['query'])) {
            $url .= '?' . $parsed['query'];
        }
        
        if (isset($parsed['fragment'])) {
            $url .= '#' . $parsed['fragment'];
        }
        
        return $url;
    }
    
    /**
     * Проверить доступность URL
     */
    private function isReachable(string $url): bool
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode >= 200 && $httpCode < 400;
    }
    
    /**
     * Получить ошибки
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
    
    /**
     * Получить предупреждения
     */
    public function getWarnings(): array
    {
        return $this->warnings;
    }
    
    /**
     * Получить все сообщения
     */
    public function getMessages(): array
    {
        return [
            'errors' => $this->errors,
            'warnings' => $this->warnings
        ];
    }
}
