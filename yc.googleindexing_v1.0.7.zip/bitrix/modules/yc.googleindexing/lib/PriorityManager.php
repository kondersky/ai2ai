<?php
/**
 * Priority Queue Manager - Управление приоритетами очереди
 * 
 * @package Yc\GoogleIndexing
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

namespace Yc\GoogleIndexing;

use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;

class PriorityManager
{
    private const MODULE_ID = 'yc.googleindexing';
    
    /**
     * Получить следующую пачку URL для отправки
     */
    public static function getNextBatch(int $limit = 50): array
    {
        $connection = Application::getConnection();
        
        // Приоритеты: HIGH > MEDIUM > LOW
        // Также учитываем количество попыток и время последней попытки
        $sql = "
            SELECT * FROM b_yc_gindex_queue 
            WHERE STATUS = 'NEW'
            AND (
                RETRY_AFTER IS NULL 
                OR RETRY_AFTER <= NOW()
                OR RETRY_AFTER <= DATE_ADD(NOW(), INTERVAL 1 HOUR)
            )
            ORDER BY 
                CASE PRIORITY
                    WHEN 'HIGH' THEN 1
                    WHEN 'MEDIUM' THEN 2
                    WHEN 'LOW' THEN 3
                END,
                CASE 
                    WHEN ATTEMPTS = 0 THEN 0
                    ELSE 1
                END,
                DATE_CREATE ASC
            LIMIT " . $limit;
        
        $result = $connection->query($sql);
        $items = [];
        
        while ($row = $result->fetch()) {
            $items[] = $row;
        }
        
        return $items;
    }
    
    /**
     * Обновить приоритет элемента
     */
    public static function updatePriority(int $id, string $priority): bool
    {
        if (!in_array($priority, ['LOW', 'MEDIUM', 'HIGH'])) {
            return false;
        }
        
        $connection = Application::getConnection();
        $connection->query("
            UPDATE b_yc_gindex_queue 
            SET PRIORITY = '" . $connection->getSqlHelper()->forSql($priority) . "'
            WHERE ID = " . $id
        );
        
        return true;
    }
    
    /**
     * Массовое обновление приоритетов
     */
    public static function bulkUpdatePriority(array $ids, string $priority): int
    {
        if (empty($ids) || !in_array($priority, ['LOW', 'MEDIUM', 'HIGH'])) {
            return 0;
        }
        
        $connection = Application::getConnection();
        $ids = array_map('intval', $ids);
        
        $connection->query("
            UPDATE b_yc_gindex_queue 
            SET PRIORITY = '" . $connection->getSqlHelper()->forSql($priority) . "'
            WHERE ID IN (" . implode(',', $ids) . ")"
        );
        
        return count($ids);
    }
    
    /**
     * Пересчитать приоритеты на основе метаданных
     */
    public static function recalculatePriorities(): void
    {
        $connection = Application::getConnection();
        
        // Получаем все элементы с метаданными
        $result = $connection->query("
            SELECT q.ID, q.IBLOCK_ID, q.ELEMENT_ID
            FROM b_yc_gindex_queue q
            WHERE q.STATUS = 'NEW'
        ");
        
        while ($row = $result->fetch()) {
            $priority = self::calculatePriority($row['IBLOCK_ID'], $row['ELEMENT_ID']);
            
            if ($priority !== 'MEDIUM') {
                $connection->query("
                    UPDATE b_yc_gindex_queue 
                    SET PRIORITY = '" . $priority . "'
                    WHERE ID = " . $row['ID']
                );
            }
        }
    }
    
    /**
     * Рассчитать приоритет на основе метаданных
     */
    private static function calculatePriority(?int $iblockId, ?int $elementId): string
    {
        if (!$iblockId || !$elementId) {
            return 'MEDIUM';
        }
        
        // Получаем настройки инфоблока
        $iblockPriority = Option::get(self::MODULE_ID, 'iblock_priority_' . $iblockId, '');
        
        if (!empty($iblockPriority)) {
            return $iblockPriority;
        }
        
        // Проверяем свойства элемента
        try {
            \CModule::IncludeModule('iblock');
            
            $res = \CIBlockElement::GetList(
                [],
                ['ID' => $elementId, 'IBLOCK_ID' => $iblockId],
                false,
                false,
                ['ID', 'IBLOCK_ID', 'ACTIVE', 'TIMESTAMP_X', 'SHOW_COUNTER']
            );
            
            if ($element = $res->Fetch()) {
                // Активные элементы - высокий приоритет
                if ($element['ACTIVE'] !== 'Y') {
                    return 'LOW';
                }
                
                // Часто обновляемые - высокий приоритет
                $updateTime = strtotime($element['TIMESTAMP_X']);
                $hoursSinceUpdate = (time() - $updateTime) / 3600;
                
                if ($hoursSinceUpdate < 1) {
                    return 'HIGH';
                }
                
                // Популярные страницы - высокий приоритет
                if (($element['SHOW_COUNTER'] ?? 0) > 1000) {
                    return 'HIGH';
                }
            }
        } catch (\Exception $e) {
            // Игнорируем ошибки
        }
        
        return 'MEDIUM';
    }
    
    /**
     * Получить статистику по приоритетам
     */
    public static function getPriorityStats(): array
    {
        $connection = Application::getConnection();
        
        $result = $connection->query("
            SELECT 
                PRIORITY,
                STATUS,
                COUNT(*) as CNT
            FROM b_yc_gindex_queue
            GROUP BY PRIORITY, STATUS
            ORDER BY PRIORITY, STATUS
        ");
        
        $stats = [
            'HIGH' => ['NEW' => 0, 'SENT' => 0, 'ERROR' => 0],
            'MEDIUM' => ['NEW' => 0, 'SENT' => 0, 'ERROR' => 0],
            'LOW' => ['NEW' => 0, 'SENT' => 0, 'ERROR' => 0]
        ];
        
        while ($row = $result->fetch()) {
            $priority = $row['PRIORITY'];
            $status = $row['STATUS'];
            $stats[$priority][$status] = (int)$row['CNT'];
        }
        
        return $stats;
    }
}
