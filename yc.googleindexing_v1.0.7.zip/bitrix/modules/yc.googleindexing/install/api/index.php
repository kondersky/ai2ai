<?php
/**
 * REST API Endpoint
 * URL: /bitrix/api/yc_googleindexing/index.php
 * 
 * @package Yc\GoogleIndexing
 */

require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php');

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

// Only allow API requests
if (!preg_match('/^\/bitrix\/api\/yc_googleindexing\//', $_SERVER['REQUEST_URI'])) {
    http_response_code(404);
    echo json_encode(['error' => 'Not found']);
    exit;
}

// Include module and run API
\Bitrix\Main\Loader::includeModule('yc.googleindexing');

$api = new Yc\GoogleIndexing\RestApi();
$api->run();
