<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.7',
    'VERSION_DATE' => '2026-03-17 05:00:00',
];
