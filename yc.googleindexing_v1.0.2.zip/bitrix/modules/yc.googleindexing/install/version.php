<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.2',
    'VERSION_DATE' => '2026-03-17 03:15:00',
];
