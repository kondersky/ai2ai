<?php
/**
 * Module installation and uninstallation
 * 
 * @package Yc\GoogleIndexing
 */

use Bitrix\Main\Config\Option;
use Bitrix\Main\Application;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

class yc_googleindexing extends CModule
{
    const MODULE_ID = 'yc.googleindexing';
    public $MODULE_ID = 'yc.googleindexing';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $MODULE_CSS;
    public $MODULE_GROUP_RIGHTS = 'Y';
    public $errors = [];

    public function __construct()
    {
        $arModuleVersion = [];
        include(__DIR__ . '/version.php');
        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = GetMessage('YC_GOOGLEINDEXING_MODULE_NAME');
        $this->MODULE_DESCRIPTION = GetMessage('YC_GOOGLEINDEXING_MODULE_DESC');
    }

    public function DoInstall()
    {
        global $APPLICATION, $step;

        $step = intval($step);
        if ($step < 1) {
            $this->ShowInstallStep1();
        } elseif ($step == 1) {
            // Install database tables
            $this->InstallDB();
            
            // Register events
            $this->InstallEvents();
            
            // Copy admin files
            $this->InstallFiles();
            
            // Register agent
            $this->InstallAgent();
            
            // Register module
            RegisterModule($this->MODULE_ID);
            
            $this->ShowInstallStep2();
        }
    }

    public function DoUnInstall()
    {
        global $APPLICATION, $step;

        $step = intval($step);
        if ($step < 1) {
            $this->ShowUnInstallStep1();
        } elseif ($step == 1) {
            $saveData = isset($_POST['save_tables']) && $_POST['save_tables'] === 'Y';
            
            // Unregister events
            $this->UnInstallEvents();
            
            // Remove admin files
            $this->UnInstallFiles();
            
            // Remove agent
            $this->UnInstallAgent();
            
            // Drop tables if not saving
            if (!$saveData) {
                $this->UnInstallDB();
            }
            
            // Unregister module
            UnRegisterModule($this->MODULE_ID);
            
            $this->ShowUnInstallStep2();
        }
    }

    protected function ShowInstallStep1()
    {
        global $APPLICATION;
        ?>
        <form action="<?php echo $APPLICATION->GetCurPage(); ?>" method="post">
            <?php echo bitrix_sessid_post(); ?>
            <input type="hidden" name="lang" value="<?php echo LANG; ?>">
            <input type="hidden" name="id" value="<?php echo $this->MODULE_ID; ?>">
            <input type="hidden" name="install" value="Y">
            <input type="hidden" name="step" value="1">
            
            <p><?php echo GetMessage('YC_GOOGLEINDEXING_INSTALL_DESC'); ?></p>
            <p><input type="checkbox" name="save_tables" value="Y" checked> <?php echo GetMessage('YC_GOOGLEINDEXING_SAVE_TABLES'); ?></p>
            
            <input type="submit" name="inst" value="<?php echo GetMessage('YC_GOOGLEINDEXING_INSTALL'); ?>">
        </form>
        <?php
    }

    protected function ShowInstallStep2()
    {
        global $APPLICATION;
        ?>
        <p><?php echo GetMessage('YC_GOOGLEINDEXING_INSTALL_SUCCESS'); ?></p>
        <p><a href="/bitrix/admin/settings.php?lang=ru&module_id=<?php echo $this->MODULE_ID; ?>"><?php echo GetMessage('YC_GOOGLEINDEXING_SETTINGS_LINK'); ?></a></p>
        <p><a href="/bitrix/admin/yc_googleindexing_index.php"><?php echo GetMessage('YC_GOOGLEINDEXING_ADMIN_LINK'); ?></a></p>
        <?php
    }

    protected function ShowUnInstallStep1()
    {
        global $APPLICATION;
        ?>
        <form action="<?php echo $APPLICATION->GetCurPage(); ?>" method="post">
            <?php echo bitrix_sessid_post(); ?>
            <input type="hidden" name="lang" value="<?php echo LANG; ?>">
            <input type="hidden" name="id" value="<?php echo $this->MODULE_ID; ?>">
            <input type="hidden" name="uninstall" value="Y">
            <input type="hidden" name="step" value="1">
            
            <p><?php echo GetMessage('YC_GOOGLEINDEXING_UNINSTALL_CONFIRM'); ?></p>
            <p><input type="checkbox" name="save_tables" value="Y" checked> <?php echo GetMessage('YC_GOOGLEINDEXING_SAVE_TABLES'); ?></p>
            
            <input type="submit" name="inst" value="<?php echo GetMessage('YC_GOOGLEINDEXING_UNINSTALL'); ?>">
        </form>
        <?php
    }

    protected function ShowUnInstallStep2()
    {
        ?>
        <p><?php echo GetMessage('YC_GOOGLEINDEXING_UNINSTALL_SUCCESS'); ?></p>
        <?php
    }

    public function InstallDB()
    {
        global $DB;
        
        try {
            // Queue table
            $DB->Query("
                CREATE TABLE IF NOT EXISTS b_yc_gindex_queue (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    IBLOCK_ID int(11) DEFAULT NULL,
                    ELEMENT_ID int(11) DEFAULT NULL,
                    SECTION_ID int(11) DEFAULT NULL,
                    SITE_ID char(2) DEFAULT NULL,
                    URL varchar(512) NOT NULL,
                    TYPE enum('URL_UPDATED','URL_DELETED') DEFAULT 'URL_UPDATED',
                    STATUS enum('NEW','SENT','ERROR') DEFAULT 'NEW',
                    PRIORITY enum('LOW','MEDIUM','HIGH') DEFAULT 'MEDIUM',
                    HTTP_CODE varchar(10) DEFAULT NULL,
                    ATTEMPTS int(11) DEFAULT 0,
                    RETRY_AFTER datetime DEFAULT NULL,
                    LAST_ERROR text,
                    DATE_CREATE datetime NOT NULL,
                    DATE_SENT datetime DEFAULT NULL,
                    PRIMARY KEY (ID),
                    INDEX IX_STATUS (STATUS),
                    INDEX IX_PRIORITY (PRIORITY),
                    INDEX IX_DATE_CREATE (DATE_CREATE)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ", true);

            // Quota table
            $DB->Query("
                CREATE TABLE IF NOT EXISTS b_yc_gindex_quota (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    DATE_DAY date NOT NULL,
                    SENT_COUNT int(11) DEFAULT 0,
                    LIMIT_DAY int(11) DEFAULT 200,
                    DATE_CREATE datetime NOT NULL,
                    PRIMARY KEY (ID),
                    UNIQUE KEY UX_DATE_DAY (DATE_DAY)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ", true);

            // Log table
            $DB->Query("
                CREATE TABLE IF NOT EXISTS b_yc_gindex_log (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    EVENT_TYPE varchar(50) NOT NULL,
                    MESSAGE text,
                    QUEUE_ID int(11) DEFAULT NULL,
                    DATE_CREATE datetime NOT NULL,
                    PRIMARY KEY (ID),
                    INDEX IX_DATE_CREATE (DATE_CREATE)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ", true);

            // Credentials table
            $DB->Query("
                CREATE TABLE IF NOT EXISTS b_yc_gindex_credentials (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    JSON_KEY longtext NOT NULL,
                    SERVICE_EMAIL varchar(255) DEFAULT NULL,
                    DATE_CREATE datetime NOT NULL,
                    PRIMARY KEY (ID)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ", true);

            // Iblocks settings table
            $DB->Query("
                CREATE TABLE IF NOT EXISTS b_yc_gindex_iblocks (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    IBLOCK_ID int(11) NOT NULL,
                    PRIORITY enum('LOW','MEDIUM','HIGH') DEFAULT 'MEDIUM',
                    ACTIVE char(1) DEFAULT 'Y',
                    DATE_CREATE datetime NOT NULL,
                    PRIMARY KEY (ID),
                    UNIQUE KEY UX_IBLOCK_ID (IBLOCK_ID)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ", true);

            return true;
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            return false;
        }
    }

    public function UnInstallDB()
    {
        global $DB;
        
        $DB->Query("DROP TABLE IF EXISTS b_yc_gindex_queue");
        $DB->Query("DROP TABLE IF EXISTS b_yc_gindex_quota");
        $DB->Query("DROP TABLE IF EXISTS b_yc_gindex_log");
        $DB->Query("DROP TABLE IF EXISTS b_yc_gindex_credentials");
        $DB->Query("DROP TABLE IF EXISTS b_yc_gindex_iblocks");

        return true;
    }

    public function InstallEvents()
    {
        $eventManager = \Bitrix\Main\EventManager::getInstance();
        
        // Menu
        $eventManager->registerEventHandler(
            'main',
            'OnBuildGlobalMenu',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\MenuManager',
            'onBuildGlobalMenu'
        );
        
        // Iblock elements
        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockElementAdd',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementAdd'
        );
        
        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockElementUpdate',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementUpdate'
        );
        
        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockElementDelete',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementDelete'
        );

        // Iblock sections
        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockSectionAdd',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionAdd'
        );

        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockSectionUpdate',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionUpdate'
        );

        $eventManager->registerEventHandler(
            'iblock',
            'OnAfterIBlockSectionDelete',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionDelete'
        );

        return true;
    }

    public function UnInstallEvents()
    {
        $eventManager = \Bitrix\Main\EventManager::getInstance();
        
        $eventManager->unRegisterEventHandler(
            'main',
            'OnBuildGlobalMenu',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\MenuManager',
            'onBuildGlobalMenu'
        );
        
        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockElementAdd',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementAdd'
        );
        
        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockElementUpdate',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementUpdate'
        );
        
        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockElementDelete',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockElementDelete'
        );

        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockSectionAdd',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionAdd'
        );

        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockSectionUpdate',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionUpdate'
        );

        $eventManager->unRegisterEventHandler(
            'iblock',
            'OnAfterIBlockSectionDelete',
            $this->MODULE_ID,
            'Yc\GoogleIndexing\EventHandler',
            'onAfterIBlockSectionDelete'
        );

        return true;
    }

    public function InstallFiles()
    {
        CopyDirFiles(
            __DIR__ . '/admin/',
            $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/',
            true,
            true
        );

        return true;
    }

    public function UnInstallFiles()
    {
        DeleteFile($_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin/yc_googleindexing_index.php');

        return true;
    }

    public function InstallAgent()
    {
        $interval = Option::get($this->MODULE_ID, 'AGENT_INTERVAL', 300);
        
        CAgent::AddAgent(
            "\\Yc\\GoogleIndexing\\Agent::sendQueue();",
            $this->MODULE_ID,
            "N",
            $interval,
            "",
            "Y",
            "",
            100
        );

        return true;
    }

    public function UnInstallAgent()
    {
        CAgent::RemoveAgent("\\Yc\\GoogleIndexing\\Agent::sendQueue();");

        return true;
    }
}
