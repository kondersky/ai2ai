<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.1',
    'VERSION_DATE' => '2026-03-17 02:50:00',
];
