<?php
/**
 * Module messages
 */
$MESS['YC_GOOGLEINDEXING_MENU_TEXT'] = 'Google Indexing API';
$MESS['YC_GOOGLEINDEXING_MENU_TITLE'] = 'Google Indexing API PRO';
