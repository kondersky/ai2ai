<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.4',
    'VERSION_DATE' => '2026-03-17 03:45:00',
];
