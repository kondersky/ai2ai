<?php
/**
 * Module messages
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$MESS['YC_GOOGLEINDEXING_MENU_TEXT'] = 'Google Indexing API';
$MESS['YC_GOOGLEINDEXING_MENU_TITLE'] = 'Google Indexing API PRO';
