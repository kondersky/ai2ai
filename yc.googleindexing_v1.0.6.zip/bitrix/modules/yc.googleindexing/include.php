<?php
/**
 * Google Indexing API PRO - main include file
 * 
 * @package Yc\GoogleIndexing
 * @version 1.0.6
 */

use Bitrix\Main\Loader;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

// Register autoloader
Loader::registerAutoLoadClasses(
    'yc.googleindexing',
    [
        // Core
        'Yc\GoogleIndexing\GoogleApiClient' => 'lib/GoogleApiClient.php',
        'Yc\GoogleIndexing\JwtHelper' => 'lib/JwtHelper.php',
        
        // Database
        'Yc\GoogleIndexing\QueueTable' => 'lib/QueueTable.php',
        'Yc\GoogleIndexing\LogTable' => 'lib/LogTable.php',
        'Yc\GoogleIndexing\CredentialsTable' => 'lib/CredentialsTable.php',
        'Yc\GoogleIndexing\QuotaTable' => 'lib/QuotaTable.php',
        
        // Event & Agent
        'Yc\GoogleIndexing\EventHandler' => 'lib/EventHandler.php',
        'Yc\GoogleIndexing\Agent' => 'lib/Agent.php',
        'Yc\GoogleIndexing\MenuManager' => 'lib/MenuManager.php',
        
        // Settings
        'Yc\GoogleIndexing\IblockSettings' => 'lib/IblockSettings.php',
        
        // Advanced Features (v1.0.6+)
        'Yc\GoogleIndexing\WebhookManager' => 'lib/WebhookManager.php',
        'Yc\GoogleIndexing\Analytics' => 'lib/Analytics.php',
        'Yc\GoogleIndexing\RestApi' => 'lib/RestApi.php',
        'Yc\GoogleIndexing\SmartCache' => 'lib/SmartCache.php',
        'Yc\GoogleIndexing\PriorityManager' => 'lib/PriorityManager.php',
        'Yc\GoogleIndexing\NotificationManager' => 'lib/NotificationManager.php',
    ]
);
