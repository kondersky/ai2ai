<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.6',
    'VERSION_DATE' => '2026-03-17 04:30:00',
];
