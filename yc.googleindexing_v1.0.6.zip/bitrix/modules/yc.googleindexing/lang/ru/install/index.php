<?php
/**
 * Russian language messages
 */

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

$MESS['YC_GOOGLEINDEXING_MODULE_NAME'] = 'Google Indexing API PRO';
$MESS['YC_GOOGLEINDEXING_MODULE_DESC'] = 'Модуль для автоматической отправки URL в Google Indexing API';

$MESS['YC_GOOGLEINDEXING_MENU_TEXT'] = 'Google Indexing API';
$MESS['YC_GOOGLEINDEXING_MENU_TITLE'] = 'Управление Google Indexing API';

// Tabs
$MESS['YC_GOOGLEINDEXING_TAB_MAIN'] = 'Главная';
$MESS['YC_GOOGLEINDEXING_TAB_SETTINGS'] = 'Настройки';
$MESS['YC_GOOGLEINDEXING_TAB_QUEUE'] = 'Очередь';
$MESS['YC_GOOGLEINDEXING_TAB_LOGS'] = 'Логи';

// Main tab
$MESS['YC_GOOGLEINDEXING_TODAY_SENT'] = 'Отправлено сегодня';
$MESS['YC_GOOGLEINDEXING_REMAINING'] = 'Осталось';
$MESS['YC_GOOGLEINDEXING_IN_QUEUE'] = 'В очереди (NEW)';
$MESS['YC_GOOGLEINDEXING_ERRORS_TODAY'] = 'Ошибок сегодня';
$MESS['YC_GOOGLEINDEXING_TOTAL_QUEUE'] = 'Всего в очереди';
$MESS['YC_GOOGLEINDEXING_SENT'] = 'Отправлено';
$MESS['YC_GOOGLEINDEXING_ERRORS'] = 'Ошибок';
$MESS['YC_GOOGLEINDEXING_QUOTA_HISTORY'] = 'История квот';
$MESS['YC_GOOGLEINDEXING_LAST_LOGS'] = 'Последние логи';

// Settings tab
$MESS['YC_GOOGLEINDEXING_SETTINGS_TITLE'] = 'Настройки подключения';
$MESS['YC_GOOGLEINDEXING_CONNECTED'] = 'Подключено:';
$MESS['YC_GOOGLEINDEXING_JSON_KEY_LABEL'] = 'JSON ключ сервис-аккаунта Google:';
$MESS['YC_GOOGLEINDEXING_SAVE'] = 'Сохранить';
$MESS['YC_GOOGLEINDEXING_CHECK_AUTH'] = 'Проверить авторизацию';
$MESS['YC_GOOGLEINDEXING_TEST_PUBLISH'] = 'Тестовая отправка';
$MESS['YC_GOOGLEINDEXING_TEST_URL_LABEL'] = 'URL для теста:';
$MESS['YC_GOOGLEINDEXING_SEND_TEST'] = 'Отправить тестовый URL';
$MESS['YC_GOOGLEINDEXING_RUN_AGENT'] = 'Запустить агент';
$MESS['YC_GOOGLEINDEXING_MANUAL_RUN'] = 'Ручной запуск';

// Queue tab
$MESS['YC_GOOGLEINDEXING_QUEUE_TITLE'] = 'Очередь URL';
$MESS['YC_GOOGLEINDEXING_EXPORT_CSV'] = 'Экспорт CSV';
$MESS['YC_GOOGLEINDEXING_NO_DATA'] = 'Нет данных';

// Logs tab
$MESS['YC_GOOGLEINDEXING_LOGS_TITLE'] = 'Логи';
$MESS['YC_GOOGLEINDEXING_CLEANUP_LOGS'] = 'Очистить логи старше 30 дней';
$MESS['YC_GOOGLEINDEXING_DELETE_LOGS_CONFIRM'] = 'Удалить логи старше 30 дней?';

// Status
$MESS['YC_GOOGLEINDEXING_STATUS_NEW'] = 'NEW';
$MESS['YC_GOOGLEINDEXING_STATUS_SENT'] = 'SENT';
$MESS['YC_GOOGLEINDEXING_STATUS_ERROR'] = 'ERROR';

// Types
$MESS['YC_GOOGLEINDEXING_TYPE_UPDATED'] = 'URL_UPDATED';
$MESS['YC_GOOGLEINDEXING_TYPE_DELETED'] = 'URL_DELETED';

// Messages
$MESS['YC_GOOGLEINDEXING_SAVED'] = 'Сохранено успешно';
$MESS['YC_GOOGLEINDEXING_AUTH_SUCCESS'] = 'Авторизация успешна!';
$MESS['YC_GOOGLEINDEXING_AUTH_FAILED'] = 'Ошибка авторизации';
$MESS['YC_GOOGLEINDEXING_TEST_SUCCESS'] = 'URL успешно отправлен в Google!';
$MESS['YC_GOOGLEINDEXING_TEST_FAILED'] = 'Ошибка отправки';
$MESS['YC_GOOGLEINDEXING_CLEANUP_SUCCESS'] = 'Удалено записей: ';
$MESS['YC_GOOGLEINDEXING_NO_CREDENTIALS'] = 'Нет сохранённых ключей';
$MESS['YC_GOOGLEINDEXING_LOADING'] = 'Загрузка...';

// Errors
$MESS['YC_GOOGLEINDEXING_ERROR_JSON'] = 'Неверный JSON: ';
$MESS['YC_GOOGLEINDEXING_ERROR_FIELDS'] = 'Отсутствуют обязательные поля: client_email или private_key';
$MESS['YC_GOOGLEINDEXING_ERROR_SAVE'] = 'Ошибка сохранения';
$MESS['YC_GOOGLEINDEXING_ERROR_MODULE'] = 'Модуль не установлен';

// Table headers
$MESS['YC_GOOGLEINDEXING_TABLE_ID'] = 'ID';
$MESS['YC_GOOGLEINDEXING_TABLE_URL'] = 'URL';
$MESS['YC_GOOGLEINDEXING_TABLE_TYPE'] = 'Тип';
$MESS['YC_GOOGLEINDEXING_TABLE_STATUS'] = 'Статус';
$MESS['YC_GOOGLEINDEXING_TABLE_PRIORITY'] = 'Приоритет';
$MESS['YC_GOOGLEINDEXING_TABLE_HTTP'] = 'HTTP';
$MESS['YC_GOOGLEINDEXING_TABLE_DATE_CREATE'] = 'Создано';
$MESS['YC_GOOGLEINDEXING_TABLE_DATE_SENT'] = 'Отправлено';
$MESS['YC_GOOGLEINDEXING_TABLE_TIME'] = 'Время';
$MESS['YC_GOOGLEINDEXING_TABLE_MESSAGE'] = 'Сообщение';
$MESS['YC_GOOGLEINDEXING_TABLE_QUEUE_ID'] = 'Queue ID';

// Installation
$MESS['YC_GOOGLEINDEXING_INSTALL_TITLE'] = 'Установка модуля';
$MESS['YC_GOOGLEINDEXING_INSTALL'] = 'Установить модуль';
$MESS['YC_GOOGLEINDEXING_INSTALL_DESC'] = 'Модуль "Google Indexing API PRO" позволяет автоматически отправлять URL страниц сайта в Google Indexing API при изменении элементов инфоблоков.';
$MESS['YC_GOOGLEINDEXING_INSTALL_SUCCESS'] = 'Модуль успешно установлен!';
$MESS['YC_GOOGLEINDEXING_INSTALL_SETTINGS'] = 'Перейдите в настройки модуля для загрузки JSON ключа.';
$MESS['YC_GOOGLEINDEXING_SETTINGS_LINK'] = 'Настройки модуля';
$MESS['YC_GOOGLEINDEXING_ADMIN_LINK'] = 'Управление модулем';
$MESS['YC_GOOGLEINDEXING_UNINSTALL_TITLE'] = 'Удаление модуля';
$MESS['YC_GOOGLEINDEXING_UNINSTALL'] = 'Удалить модуль';
$MESS['YC_GOOGLEINDEXING_UNINSTALL_CONFIRM'] = 'Вы уверены, что хотите удалить модуль "Google Indexing API PRO"?';
$MESS['YC_GOOGLEINDEXING_UNINSTALL_SUCCESS'] = 'Модуль успешно удалён!';
$MESS['YC_GOOGLEINDEXING_SAVE_TABLES'] = 'Сохранить таблицы и данные модуля';

// New Features v1.0.6
$MESS['YC_GOOGLEINDEXING_TAB_ANALYTICS'] = 'Аналитика';
$MESS['YC_GOOGLEINDEXING_TAB_API'] = 'REST API';
$MESS['YC_GOOGLEINDEXING_TAB_NOTIFICATIONS'] = 'Уведомления';

// Analytics
$MESS['YC_GOOGLEINDEXING_ANALYTICS_TITLE'] = 'Аналитика и статистика';
$MESS['YC_GOOGLEINDEXING_SUCCESS_RATE'] = 'Процент успешных';
$MESS['YC_GOOGLEINDEXING_AVG_TIME'] = 'Среднее время';
$MESS['YC_GOOGLEINDEXING_WEEK_STATS'] = 'Статистика за неделю';
$MESS['YC_GOOGLEINDEXING_IBLOCK_STATS'] = 'По инфоблокам';
$MESS['YC_GOOGLEINDEXING_TOP_FAILED'] = 'Частые ошибки';

// REST API
$MESS['YC_GOOGLEINDEXING_API_TITLE'] = 'REST API';
$MESS['YC_GOOGLEINDEXING_API_KEY'] = 'API ключ';
$MESS['YC_GOOGLEINDEXING_API_GENERATE'] = 'Сгенерировать ключ';
$MESS['YC_GOOGLEINDEXING_API_ENDPOINT'] = 'Endpoint:';
$MESS['YC_GOOGLEINDEXING_API_ENABLED'] = 'Включить REST API';
$MESS['YC_GOOGLEINDEXING_API_DOCS'] = 'Документация API';

// Notifications
$MESS['YC_GOOGLEINDEXING_NOTIFY_TITLE'] = 'Настройки уведомлений';
$MESS['YC_GOOGLEINDEXING_NOTIFY_EMAIL'] = 'Email для уведомлений';
$MESS['YC_GOOGLEINDEXING_NOTIFY_ON_SUCCESS'] = 'Уведомлять об успешной отправке';
$MESS['YC_GOOGLEINDEXING_NOTIFY_ON_ERROR'] = 'Уведомлять об ошибках';
$MESS['YC_GOOGLEINDEXING_NOTIFY_ON_QUOTA'] = 'Уведомлять о лимите квоты';
$MESS['YC_GOOGLEINDEXING_NOTIFY_TELEGRAM'] = 'Telegram уведомления';
$MESS['YC_GOOGLEINDEXING_TELEGRAM_TOKEN'] = 'Telegram Bot Token';
$MESS['YC_GOOGLEINDEXING_TELEGRAM_CHAT'] = 'Telegram Chat ID';
$MESS['YC_GOOGLEINDEXING_NOTIFY_SLACK'] = 'Slack уведомления';
$MESS['YC_GOOGLEINDEXING_SLACK_WEBHOOK'] = 'Slack Webhook URL';

// Webhook
$MESS['YC_GOOGLEINDEXING_WEBHOOK_TITLE'] = 'Webhook';
$MESS['YC_GOOGLEINDEXING_WEBHOOK_URL'] = 'URL webhook';
$MESS['YC_GOOGLEINDEXING_WEBHOOK_ENABLED'] = 'Включить webhook';

// Cache
$MESS['YC_GOOGLEINDEXING_CACHE_TITLE'] = 'Кэширование';
$MESS['YC_GOOGLEINDEXING_CACHE_ENABLED'] = 'Включить кэширование';
$MESS['YC_GOOGLEINDEXING_CACHE_TTL'] = 'Время жизни кэша (сек)';
$MESS['YC_GOOGLEINDEXING_CACHE_CLEAR'] = 'Очистить кэш';
$MESS['YC_GOOGLEINDEXING_CACHE_STATS'] = 'Статистика кэша';

// Priority
$MESS['YC_GOOGLEINDEXING_PRIORITY_STATS'] = 'Статистика по приоритетам';
$MESS['YC_GOOGLEINDEXING_PRIORITY_HIGH'] = 'Высокий';
$MESS['YC_GOOGLEINDEXING_PRIORITY_MEDIUM'] = 'Средний';
$MESS['YC_GOOGLEINDEXING_PRIORITY_LOW'] = 'Низкий';
