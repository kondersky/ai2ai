<?php
/**
 * Версия модуля
 */

$arModuleVersion = [
    'VERSION' => '1.0.3',
    'VERSION_DATE' => '2026-03-17 03:30:00',
];
